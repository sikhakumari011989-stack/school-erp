# ACADEMIC OS — STAGING REVIEW PACKAGE V2 MANIFEST
**Package Name:** `academic-os-staging-review-v2.zip`  
**Version:** 2.0.0 (Post-Independent Review Fixes)  
**Date Generated:** 2026-11-04  
**Classification:** Confidential Staging Review & Security Evaluation Package  

---

## 1. Directory Structure & Included Files

```
academic-os-staging-review-v2.zip
├── migrations/
│   ├── 01_rls_policies.sql
│   ├── 02_pre_commercial_hardening.sql
│   ├── 03_rls_hardening.sql
│   ├── 18_auth_identity_and_profiles_rls_hardening.sql
│   ├── 19_master_setup_and_licensing.sql
│   ├── 20_class_test_marks.sql
│   ├── 21_security_and_financial_hardening.sql
│   ├── 22_phase2_security_and_rls_hardening.sql
│   └── 23_sales_readiness_and_subscription_hardening.sql
├── rollback/
│   └── rollback_21_22_23.sql
├── verification/
│   ├── staging-database-verification.sql
│   └── inspect-database-schema.sql
├── security-tests/
│   ├── security-authorization.test.js
│   └── class-test-marks.test.js
├── guides/
│   ├── OWNER_ACTIONS.md
│   ├── DEPLOYMENT_GUIDE.md
│   ├── SUPABASE_SETUP_GUIDE.md
│   ├── SCHOOL_ONBOARDING_GUIDE.md
│   └── BACKUP_AND_RECOVERY.md
├── reports/
│   ├── SALES_READINESS_REPORT.md
│   └── STAGING_TEST_RESULTS.md
├── MANIFEST.md
├── BUILD_AND_TEST_RESULTS.md
└── UNRESOLVED_ISSUES.md
```

---

## 2. Inventory of Changes in Package v2

1. **`migrations/21_security_and_financial_hardening.sql`:**
   - Safe schema-aware reconciliation of `public.audit_logs` (all columns added with `IF NOT EXISTS`).
   - `log_audit_event()` fails closed on error (`RAISE EXCEPTION`) without silently swallowing exceptions.
   - `audit_logs` is immutable: `UPDATE`, `DELETE`, `TRUNCATE` revoked from all authenticated/anon roles.
   - Idempotency checks and pessimistic row locks scoped to authenticated tenant (`school_id = v_tenant`).
   - Direct reversal cannot bypass maker-checker workflow: requires an independent pending reversal request (`requester_id != auth.uid()`).
   - Reversal ID and credit note generated using `text` format compatible with real `fee_ledger.id` primary key.

2. **`migrations/22_phase2_security_and_rls_hardening.sql`:**
   - Hardened `profiles_canonical_insert`: restricted to Executive Admins for their school (`PRIN`, `HOD`) and `service_role`.
   - Privilege escalation guard trigger (`protect_profile_privileged_columns`) attached to `BEFORE INSERT OR UPDATE ON public.profiles`.
   - Prevents non-administrative callers from self-assigning administrative roles or custom statuses on INSERT and UPDATE.
   - Prevents cross-tenant profile migrations (`school_id` modifications blocked).
   - Dynamic catalog sweep of all unlisted permissive policies on core tables via `pg_policies`.
   - Preserved tenant isolation in `claim_next_pdf_job`.

3. **`migrations/23_sales_readiness_and_subscription_hardening.sql`:**
   - `provision_institutional_school` dynamically reconciles `profiles.school_id` data type (UUID vs TEXT), preventing type mismatch errors.
   - Inter-school administrator overwrite protection prevents one school's provisioning from affecting another school's profile.
   - `payment_orders` SELECT access restricted to authorized staff (`ACC`, `PRIN`, `HOD`) and the relevant customer student.
   - Column-level permissions revoke `raw_payload` from regular authenticated users.
   - Cryptographic verification in `/api/razorpay/verify-payment` validates payment order tenant ownership, amount, and idempotency.

4. **`rollback/rollback_21_22_23.sql`:**
   - Syntactically valid in Supabase SQL Editor (`RAISE NOTICE` enclosed in `DO $$ ... $$` blocks).
   - Preserves tenant isolation in `claim_next_pdf_job` (does not restore insecure wide-open function).
   - Preserves all transaction and audit tables (`fee_ledger`, `fee_reversal_requests`, `audit_logs`, `payment_orders`).
   - Includes pre-rollback checks and post-rollback verification assertions.

5. **`verification/staging-database-verification.sql`:**
   - 100% executable in Supabase SQL Editor.
   - Standard PostgreSQL `DO $$ ... $$` blocks with zero psql metacommands.
   - Tests RLS using real authenticated identities and role switching (`SET LOCAL ROLE authenticated`).
   - 8 comprehensive test stages covering all 6 canonical roles, 2 schools, privilege escalation, maker-checker reversals, audit immutability, PDF queue isolation, and payment order isolation.
   - Non-destructive execution: wrapped in `BEGIN ... ROLLBACK;`.

6. **`verification/inspect-database-schema.sql`:**
   - Read-only schema inspection script for live Supabase databases.
