# ACADEMIC OS — UNRESOLVED ISSUES & OPERATIONAL PREREQUISITES (v2)
**Document Classification:** Technical Disclosure & Staging Prerequisites  
**Target Reviewer:** Independent Security & Database Migration Reviewer  
**Status Date:** 2026-11-04  

---

## 1. Supabase Auth (`auth.users`) vs. Application Profiles (`public.profiles`)
* **Finding:**  
  In the Supabase architecture, user authentication credentials (`auth.users`) exist in an internal schema managed by Supabase GoTrue, while application profiles exist in `public.profiles`.
* **Current Behavior:**  
  When an institution is provisioned via `/master-setup` or the `provision_institutional_school` RPC, a row is created in `public.schools`, `public.school_licenses`, and `public.profiles` (with `role = 'principal'` or `'trustee'`, and `role_code = 'PRIN-01'` or `'HOD-01'`).
* **Requirement for Live Sign-in:**  
  Inserting a row into `public.profiles` does NOT automatically register a hashed password in `auth.users`. To enable password-based login through Supabase Auth, the platform administrator must either:
  1. Invite the user via Supabase Dashboard -> **Authentication** -> **Users** -> **Invite User**; or
  2. Trigger the Supabase Auth Admin API (`supabase.auth.admin.createUser`) using the `SUPABASE_SERVICE_ROLE_KEY` in a secure serverless script; or
  3. Have the user sign up with the provisioned email and bind their profile UUID to `auth.users.id`.
* **Resolution in Staging Package:**  
  The RPC return value and `OWNER_ACTIONS.md` explicitly document this separation (`auth_account_created: false`) so operators do not assume `public.profiles` insertion creates a GoTrue password credential. A complete Node.js script is provided in `OWNER_ACTIONS.md` Section 5.

---

## 2. Remote Live Database Verification Pending Owner Execution
* **Finding:**  
  By design and strict mandate, the AI assistant does not possess credentials to execute DDL or DML against the owner's remote live Supabase database.
* **Status:**  
  The verification script `tests/staging-database-verification.sql` has been completely rebuilt with 8 isolated test suites, uses PostgreSQL `DO $$ ... $$` blocks without psql metacommands, and is wrapped in an explicit `BEGIN ... ROLLBACK;` block.
* **Requirement:**  
  The repository owner must copy and execute `tests/staging-database-verification.sql` in their Supabase SQL Editor and confirm that all 8 stages output their respective `NOTICE` lines.

---

## 3. Live Gateway Key Provisioning
* **Finding:**  
  Serverless online fee collection endpoints (`/api/razorpay/create-order` and `/api/razorpay/verify-payment`) operate in test mode when provided valid Razorpay test keys.
* **Requirement:**  
  The owner must register a Razorpay account, obtain `rzp_test_...` credentials, and configure `VITE_RAZORPAY_KEY_ID`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET` in Vercel before live payment modal verification can occur.

---

## 4. Live Database Schema Assumptions & Read-Only Inspection Strategy
* **Assumption 1 (`fee_ledger.id`):** Primary key is `text` (`TXN-...`). Handled: Reversals generate text credit notes (`CN-...`) and use text references without UUID casting.
* **Assumption 2 (`profiles.school_id`):** May be UUID or TEXT across different installation histories. Handled: `provision_institutional_school` dynamically detects column data type via `information_schema.columns` and adapts parameter binding.
* **Assumption 3 (`audit_logs`):** Pre-existing installations may lack specific columns. Handled: Safe column reconciliation (`ALTER TABLE ADD COLUMN IF NOT EXISTS`) and fail-closed trigger logic.
* **Inspection Tool:** The repository owner can run [`scripts/inspect-database-schema.sql`](file:///c:/Users/Astik/school-app/scripts/inspect-database-schema.sql) in their Supabase SQL Editor to verify live table columns, constraints, RLS policies, and routine grants.

---

## 5. Summary Risk Assessment
* **Schema Integrity:** HIGH CONFIDENCE — All column names, foreign keys, and function signatures reconciled with schema-aware fallback.
* **Cross-Tenant Isolation:** HIGH CONFIDENCE — Single-authority RLS policies on `schools`, `profiles`, `fee_ledger`, `fee_reversal_requests`, and `payment_orders` strictly prevent data leakage.
* **Privilege Escalation:** HIGH CONFIDENCE — Database-level trigger on INSERT and UPDATE prevents client manipulation of `role`, `role_code`, `school_id`, and `status`.
* **Maker-Checker Financial Reversals:** HIGH CONFIDENCE — Direct reversal bypass eliminated; PostgreSQL enforces maker != checker.
* **Production Deployment Readiness:** CONDITIONAL — Requires owner execution of migrations and staging verification script in their staging Supabase project.
