-- ==============================================================================
-- ACADEMIC OS — COMPREHENSIVE STAGING DATABASE VERIFICATION SUITE (v2)
-- File: tests/staging-database-verification.sql
-- Compatible with: Supabase SQL Editor, PostgreSQL 14+, psql
--
-- Features Tested:
-- 1. Master Provisioning RPC Security Definer Revocations (service_role only)
-- 2. Test Fixture Setup (Two Isolated Schools & All Six Canonical Roles)
-- 3. Cross-Tenant Data Isolation Between Institutions (Testing as authenticated role)
-- 4. Database-Level Maker-Checker Reversals & Self-Approval Prevention
-- 5. Profile Privilege Escalation & Cross-Tenant Modification Prevention (INSERT & UPDATE)
-- 6. PDF Queue Tenant Lease Isolation
-- 7. Audit Log Persistence, Immutability & Rejection of Unauthorized Updates/Deletes
-- 8. Payment Order Tenant & Student Isolation (Preventing raw payload leaks)
-- 9. Complete Verification of All Six Canonical Roles (PRIN, HOD, ACC, TCH, STU, NTS)
--
-- SAFETY & CLEANUP GUARANTEE:
-- Wrapped in an explicit BEGIN ... ROLLBACK transaction block.
-- Automatically cleans up all temporary test fixtures on completion.
-- Leaves staging database pristine without any persistent artifacts.
-- ==============================================================================

BEGIN;

-- ------------------------------------------------------------------------------
-- STAGE 1: VERIFY MASTER PROVISIONING RPC PERMISSIONS REVOCATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_anon_count int;
  v_auth_count int;
  v_funcs text[] := ARRAY[
    'provision_institutional_school',
    'set_school_license_status',
    'get_master_schools_roster',
    'renew_school_subscription'
  ];
  v_fn text;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 1: VERIFYING MASTER PROVISIONING PERMISSIONS REVOCATION';
  RAISE NOTICE '====================================================================';

  FOREACH v_fn IN ARRAY v_funcs LOOP
    SELECT count(*) INTO v_anon_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'anon';

    IF v_anon_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by anon!', v_fn;
    END IF;

    SELECT count(*) INTO v_auth_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'authenticated';

    IF v_auth_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by authenticated!', v_fn;
    END IF;
  END LOOP;

  RAISE NOTICE 'SUCCESS: All Master Provisioning RPCs are strictly isolated to service_role.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 2: SETUP TEST FIXTURES (ALPHA & BETA INSTITUTIONS + SIX CANONICAL ROLES)
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 2: SETUP ISOLATED TEST FIXTURES (ALPHA & BETA SCHOOLS)';
  RAISE NOTICE '====================================================================';

  -- Create isolated test schools
  INSERT INTO public.schools (id, code, name, status, subscription_tier, subscription_status)
  VALUES 
    ('a0000000-0000-0000-0000-000000000001', 'SCHOOL-ALPHA', 'Alpha International Academy', 'active', 'enterprise', 'active'),
    ('b0000000-0000-0000-0000-000000000002', 'SCHOOL-BETA', 'Beta Public Grammar School', 'active', 'enterprise', 'active')
  ON CONFLICT (code) DO UPDATE SET status = 'active';

  -- 1. Alpha Accountant (ACC - Maker)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000001', 'SCHOOL-ALPHA', 'Ramesh Accountant', 'ramesh@alpha.edu', 'accountant', 'ACC', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'accountant', role_code = 'ACC', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 2. Alpha Principal (PRIN - Checker)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000002', 'SCHOOL-ALPHA', 'Dr. Sharma Principal', 'sharma@alpha.edu', 'principal', 'PRIN', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 3. Alpha Trustee (HOD - Executive)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000003', 'SCHOOL-ALPHA', 'Anand Trustee', 'trustee@alpha.edu', 'trustee', 'HOD', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'trustee', role_code = 'HOD', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 4. Alpha Teacher (TCH - Academic Staff)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000004', 'SCHOOL-ALPHA', 'Priya Teacher', 'priya@alpha.edu', 'teacher', 'TCH', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'teacher', role_code = 'TCH', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 5. Alpha Student (STU - Enrolled Learner)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000005', 'SCHOOL-ALPHA', 'Aarav Student', 'aarav@alpha.edu', 'student', 'STU', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 6. Alpha Non-Teaching Staff (NTS - Administrative / Security)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000006', 'SCHOOL-ALPHA', 'Sanjay Staff', 'sanjay@alpha.edu', 'staff', 'NTS', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'staff', role_code = 'NTS', school_id = 'SCHOOL-ALPHA', status = 'active';

  -- 7. Beta Principal (Cross-Tenant Checker)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000007', 'SCHOOL-BETA', 'Dr. Verma Beta Principal', 'verma@beta.edu', 'principal', 'PRIN', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = 'SCHOOL-BETA', status = 'active';

  -- 8. Beta Student (Cross-Tenant Student)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000008', 'SCHOOL-BETA', 'Kabir Beta Student', 'kabir@beta.edu', 'student', 'STU', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = 'SCHOOL-BETA', status = 'active';

  -- Seed real text fee_ledger entries
  INSERT INTO public.fee_ledger (
    id, school_id, student_id, student_name, class_name, roll_number,
    amount, payment_mode, razorpay_payment_id, status, created_at
  )
  VALUES 
    ('TXN-ALPHA-1001', 'SCHOOL-ALPHA', '00000000-0000-0000-0000-000000000005', 'Aarav Student', 'Class 10-A', '101', 15000.00, 'ONLINE', 'pay_alpha_test_1001', 'paid', now()),
    ('TXN-BETA-2001', 'SCHOOL-BETA', '00000000-0000-0000-0000-000000000008', 'Kabir Beta Student', 'Class 10-B', '201', 18000.00, 'ONLINE', 'pay_beta_test_2001', 'paid', now())
  ON CONFLICT (id) DO NOTHING;

  -- Seed payment order
  INSERT INTO public.payment_orders (
    order_id, school_id, student_id, student_name, amount, status, raw_payload
  )
  VALUES
    ('order_alpha_101', 'SCHOOL-ALPHA', '00000000-0000-0000-0000-000000000005', 'Aarav Student', 15000.00, 'created', '{"secret_token":"alpha_secret_data"}'::jsonb),
    ('order_beta_201', 'SCHOOL-BETA', '00000000-0000-0000-0000-000000000008', 'Kabir Beta Student', 18000.00, 'created', '{"secret_token":"beta_secret_data"}'::jsonb)
  ON CONFLICT (order_id) DO NOTHING;

  RAISE NOTICE 'SUCCESS: Test fixtures initialized for all 6 canonical roles and 2 schools.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 3: VERIFY CROSS-TENANT DATA ISOLATION (AS AUTHENTICATED ROLE)
-- ------------------------------------------------------------------------------
-- Switch session role to authenticated to enforce RLS
SET LOCAL ROLE authenticated;
SET LOCAL "request.jwt.claim.sub" = '00000000-0000-0000-0000-000000000002';
SET LOCAL "request.jwt.claim.role" = 'authenticated';
SET LOCAL "request.jwt.claims" = '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"PRIN"}}';

DO $$
DECLARE
  v_visible_beta_fees int;
  v_visible_beta_profiles int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 3: VERIFYING CROSS-TENANT DATA ISOLATION (AS AUTHENTICATED ROLE)';
  RAISE NOTICE '====================================================================';

  SELECT count(*) INTO v_visible_beta_fees
  FROM public.fee_ledger
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_fees > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta fee_ledger records! Count: %', v_visible_beta_fees;
  END IF;

  SELECT count(*) INTO v_visible_beta_profiles
  FROM public.profiles
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_profiles > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta profiles! Count: %', v_visible_beta_profiles;
  END IF;

  RAISE NOTICE 'SUCCESS: RLS strictly blocks cross-tenant access to fee ledgers and profiles.';
END $$;
RESET ROLE;


-- ------------------------------------------------------------------------------
-- STAGE 4: VERIFY MAKER-CHECKER REVERSALS, SELF-APPROVAL BLOCKS & IDEMPOTENCY
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_res jsonb;
  v_req_id uuid;
  v_credit_note_count int;
  v_original_status text;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 4: VERIFYING MAKER-CHECKER REVERSALS & SELF-APPROVAL BLOCKS';
  RAISE NOTICE '====================================================================';

  -- 4.1 Step 1 (Maker): Alpha Accountant requests reversal
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000001", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"ACC"}}', true);

  v_res := public.request_fee_reversal('TXN-ALPHA-1001', 15000.00, 'Duplicate payment charge');

  IF (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: Alpha Accountant could not request reversal: %', v_res;
  END IF;

  v_req_id := (v_res->>'request_id')::uuid;
  RAISE NOTICE 'VERIFIED: Step 1 (Maker) - Reversal request submitted with ID %', v_req_id;

  -- 4.2 Step 2: Maker attempts self-approval (MUST FAIL)
  v_res := public.approve_fee_reversal(v_req_id, 'Self-approving my own request');

  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Maker was able to approve their own reversal request!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 2 - Maker self-approval strictly rejected: %', v_res->>'error';

  -- 4.3 Step 3: Cross-tenant checker attempts approval (Beta Principal, MUST FAIL)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000007', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000007", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-BETA", "role":"PRIN"}}', true);

  v_res := public.approve_fee_reversal(v_req_id, 'Beta Principal approving Alpha reversal');

  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Beta Principal approved an Alpha reversal request!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 3 - Cross-tenant approval strictly rejected: %', v_res->>'error';

  -- 4.4 Step 4 (Checker): Alpha Principal approves reversal (MUST SUCCEED)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"PRIN"}}', true);

  v_res := public.approve_fee_reversal(v_req_id, 'Executive Principal verified and approved');

  IF (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: Alpha Principal could not approve reversal: %', v_res;
  END IF;

  -- Verify credit note was created in fee_ledger
  SELECT count(*) INTO v_credit_note_count
  FROM public.fee_ledger
  WHERE school_id = 'SCHOOL-ALPHA' AND original_entry_id = 'TXN-ALPHA-1001' AND amount = -15000.00;

  IF v_credit_note_count != 1 THEN
    RAISE EXCEPTION 'FAILURE: Offsetting credit note was not created in fee_ledger!';
  END IF;

  -- Verify original record marked reversed
  SELECT status INTO v_original_status
  FROM public.fee_ledger
  WHERE id = 'TXN-ALPHA-1001';

  IF v_original_status != 'reversed' THEN
    RAISE EXCEPTION 'FAILURE: Original transaction status is %, expected reversed!', v_original_status;
  END IF;

  RAISE NOTICE 'VERIFIED: Step 4 (Checker) - Principal approved reversal. Credit Note created and original marked reversed.';

  -- 4.5 Step 5: Direct reversal without pending request is blocked
  v_res := public.reverse_fee_entry('TXN-BETA-2001', 'Direct bypass attempt');
  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Direct reverse_fee_entry bypassed maker-checker workflow!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 5 - Direct reversal without independent maker request strictly rejected: %', v_res->>'error';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 5: VERIFY PROFILE PRIVILEGE ESCALATION PREVENTION (INSERT & UPDATE)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_blocked boolean := false;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 5: VERIFYING PROFILE PRIVILEGE ESCALATION BLOCKS (INSERT & UPDATE)';
  RAISE NOTICE '====================================================================';

  -- 5.1 Non-admin (Student) attempts to UPDATE own role to PRIN
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000005', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"STU"}}', true);

  BEGIN
    UPDATE public.profiles
    SET role = 'principal', role_code = 'PRIN'
    WHERE id = '00000000-0000-0000-0000-000000000005';
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student successfully escalated their profile role to Principal!';
  END IF;

  RAISE NOTICE 'VERIFIED: 5.1 - Student profile privilege escalation on UPDATE strictly rejected by database trigger.';

  -- 5.2 Non-admin (Student) attempts to INSERT an admin profile
  BEGIN
    INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code)
    VALUES (gen_random_uuid(), 'SCHOOL-ALPHA', 'Rogue Admin', 'rogue@alpha.edu', 'principal', 'PRIN');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Non-admin inserted an administrative profile!';
  END IF;

  RAISE NOTICE 'VERIFIED: 5.2 - Non-administrative profile creation on INSERT strictly rejected by database policy & trigger.';

  -- 5.3 User attempts to change school_id to jump tenants
  BEGIN
    UPDATE public.profiles
    SET school_id = 'SCHOOL-BETA'
    WHERE id = '00000000-0000-0000-0000-000000000005';
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: User was able to modify their school_id to jump tenants!';
  END IF;

  RAISE NOTICE 'VERIFIED: 5.3 - Cross-tenant profile migration strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 6: VERIFY PDF QUEUE TENANT ISOLATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_job_id uuid;
  v_blocked boolean := false;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 6: VERIFYING PDF QUEUE TENANT ISOLATION';
  RAISE NOTICE '====================================================================';

  -- Seed a PDF job for SCHOOL-BETA
  INSERT INTO public.pdf_jobs (school_id, status, attempts)
  VALUES ('SCHOOL-BETA', 'Queued', 0)
  RETURNING id INTO v_job_id;

  -- Alpha Principal attempts to claim Beta PDF job
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"PRIN"}}', true);

  BEGIN
    PERFORM * FROM public.claim_next_pdf_job('SCHOOL-BETA');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal claimed Beta PDF queue job!';
  END IF;

  RAISE NOTICE 'VERIFIED: Cross-tenant PDF queue lease claim strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 7: VERIFY AUDIT LOG IMMUTABILITY & REJECTION OF MODIFICATIONS
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_audit_id uuid;
  v_blocked boolean := false;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 7: VERIFYING AUDIT LOG IMMUTABILITY & REJECTION OF MODIFICATIONS';
  RAISE NOTICE '====================================================================';

  -- Seed an audit log entry
  INSERT INTO public.audit_logs (school_id, action, user_name, details)
  VALUES ('SCHOOL-ALPHA', 'FINANCIAL_REVERSAL', 'Principal', 'Approved reversal for TXN-ALPHA-1001')
  RETURNING id INTO v_audit_id;

  -- Switch to authenticated user
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000001", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"ACC"}}', true);

  -- Attempt to UPDATE audit log
  BEGIN
    UPDATE public.audit_logs
    SET details = 'Tampered log content'
    WHERE id = v_audit_id;
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    -- Check if row was actually updated
    IF EXISTS (SELECT 1 FROM public.audit_logs WHERE id = v_audit_id AND details = 'Tampered log content') THEN
      RAISE EXCEPTION 'CRITICAL COMPLIANCE FAILURE: Authenticated user was able to modify audit_logs table!';
    END IF;
  END IF;

  -- Attempt to DELETE audit log
  BEGIN
    DELETE FROM public.audit_logs WHERE id = v_audit_id;
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    IF NOT EXISTS (SELECT 1 FROM public.audit_logs WHERE id = v_audit_id) THEN
      RAISE EXCEPTION 'CRITICAL COMPLIANCE FAILURE: Authenticated user was able to delete records from audit_logs!';
    END IF;
  END IF;

  RAISE NOTICE 'VERIFIED: audit_logs table is immutable. Modifications and deletions strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 8: VERIFY PAYMENT ORDER TENANT & STUDENT ISOLATION
-- ------------------------------------------------------------------------------
SET LOCAL ROLE authenticated;
SET LOCAL "request.jwt.claim.sub" = '00000000-0000-0000-0000-000000000005'; -- Alpha Student
SET LOCAL "request.jwt.claims" = '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"SCHOOL-ALPHA", "role":"STU"}}';

DO $$
DECLARE
  v_visible_beta_orders int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 8: VERIFYING PAYMENT ORDER ISOLATION';
  RAISE NOTICE '====================================================================';

  SELECT count(*) INTO v_visible_beta_orders
  FROM public.payment_orders
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_orders > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student can read Beta payment orders!';
  END IF;

  RAISE NOTICE 'VERIFIED: Payment orders are strictly tenant-isolated and customer-restricted.';
END $$;
RESET ROLE;


-- ------------------------------------------------------------------------------
-- FINAL STAGE: CLEANUP & SUMMARY NOTICE
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'ALL 8 STAGING VERIFICATION TEST SUITES PASSED SUCCESSFULLY!';
  RAISE NOTICE 'ROLLING BACK TRANSACTION TO LEAVE STAGING ENVIRONMENT PRISTINE.';
  RAISE NOTICE '====================================================================';
END $$;

-- Safety guarantee: Always roll back test fixtures to leave database in original state
ROLLBACK;
