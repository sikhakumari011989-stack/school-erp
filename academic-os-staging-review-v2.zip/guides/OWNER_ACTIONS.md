# ACADEMIC OS — STAGING HANDOVER & OPERATIONAL RUNBOOK (v2)
**Target Environment:** Supabase PostgreSQL + Vercel Serverless + Razorpay Test Gateway  
**Document Classification:** Confidential — Platform Owner Operational Manual  
**Security Guarantee:** Contains NO hardcoded secrets or sensitive credentials.

---

## 1. PRE-DEPLOYMENT SCHEMA INSPECTION & AUDIT REPORT

Before executing migrations on your live staging instance, verify the following findings from the independent architectural inspection:

### A. Resolved Migration Conflicts & Schema Deconflictions
1. **Migration 21 Fee Reversal Authorization & Tenant Isolation Enforced:**  
   In migration 21, `reverse_fee_entry` previously accepted a caller-supplied `p_authorized_by` without checking `auth.uid()`, executive role authority, or tenant matching. It has been strictly refactored so that:
   - Caller must have a valid authenticated session (`auth.uid() IS NOT NULL`).
   - Caller must be an executive admin (`public.is_admin_or_executive()`).
   - Cross-tenant fee reversals are blocked (`school_id = v_tenant`).
   - Approver name is derived strictly from `auth.uid()` / `public.profiles`.
   - **Direct reversal cannot bypass maker-checker:** A pending reversal request submitted by an independent financial operator must exist (`requester_id != auth.uid()`).
   - **Idempotency lookup scoped to tenant:** Scoped to `school_id = v_tenant` to prevent cross-tenant idempotency collisions.
2. **Schema-Aware `audit_logs` Reconciliation & Fail-Closed Trigger:**  
   - `CREATE TABLE IF NOT EXISTS public.audit_logs` is fortified with schema-aware `ALTER TABLE ADD COLUMN IF NOT EXISTS` for all columns.
   - `log_audit_event()` trigger function now fails closed: if audit log insertion fails, the business transaction is aborted rather than silently swallowed (`RAISE EXCEPTION`).
   - `audit_logs` is immutable: `UPDATE`, `DELETE`, and `TRUNCATE` privileges are revoked from `authenticated`, `anon`, and `PUBLIC`.
3. **Database-Level Protection of Privileged Profile Columns on INSERT and UPDATE:**  
   - In migration 22, `protect_profile_privileged_columns` is attached to `BEFORE INSERT OR UPDATE ON public.profiles`.
   - `profiles_canonical_insert` strictly restricts direct profile insertion to executive administrators for their own school (`PRIN`, `HOD`) and `service_role`. Regular authenticated users cannot self-assign administrative roles or custom statuses.
   - Even executive administrators are prevented from modifying `school_id` to transfer profiles across institutions.
4. **Migration 23 Administrator Profile Reconciliation & UUID Compatibility:**  
   - `provision_institutional_school` dynamically checks `public.profiles.school_id` data type in `information_schema.columns`. If UUID, it inserts `v_school_id`; if TEXT, it inserts `v_clean_code`. This guarantees that school codes are never inserted into UUID columns.
   - Inter-school administrator overwrite protection guarantees that provisioning School B cannot overwrite or reassign School A's administrator.
   - Clearly returns `auth_account_created: false` and documents the GoTrue Admin API onboarding requirement.
5. **Reconciliation of `fee_ledger.id` TEXT Column Type:**  
   - `public.fee_ledger.id` is typed as `text PRIMARY KEY` (`TXN-...`). All references in `fee_reversal_requests.entry_id`, `request_fee_reversal`, `approve_fee_reversal`, and `reverse_fee_entry` use `text`. Credit note entries generate text identifiers (`CN-...`).
6. **Payment Orders Restricted Access & Raw Payload Protection:**  
   - `payment_orders` SELECT access is restricted to authorized staff (`ACC`, `PRIN`, `HOD`) and the relevant customer (`student_id = auth.uid()::text`).
   - Column-level grants restrict ordinary users from querying `raw_payload`.
   - Cryptographic payment verification validates tenant ownership, amount consistency, and order idempotency.
7. **Non-Destructive, Safe Rollback Procedure with Pre/Post Checks:**  
   - `supabase/migrations/rollback_21_22_23.sql` is syntactically valid in Supabase SQL Editor. It includes pre-rollback checks, preserves all financial and audit tables, preserves tenant isolation in the PDF queue function, and performs post-rollback sanity verification.
8. **Dynamic Elimination of Permissive OR-Leakage Policies:**  
   - Migration 22 uses a dynamic catalog query over `pg_policies` to drop any legacy or unlisted permissive policies on core tables (`schools`, `profiles`, `fee_reversal_requests`, `audit_logs`, `pdf_jobs`, `payment_orders`).

### B. Complete `SECURITY DEFINER` Permissions Matrix
Every elevated function enforces `search_path = public` to prevent search path poisoning, and has had unsafe permissions revoked:

| Function Signature | search_path | anon | authenticated | service_role | Enforced Caller Checks |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `provision_institutional_school(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `renew_school_subscription(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `set_school_license_status(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `get_master_schools_roster()` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `claim_next_pdf_job(text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | Authenticated tenant match enforced |
| `request_fee_reversal(text, numeric, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_financial_manager()` + tenant isolation |
| `approve_fee_reversal(uuid, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + Maker != Checker |
| `reject_fee_reversal(uuid, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + tenant match |
| `reverse_fee_entry(text, text, text, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + Maker-Checker enforced |

---

## 2. PRE-DEPLOYMENT SCHEMA INSPECTION SCRIPT

Before running migrations on staging, open Supabase SQL Editor, run [`scripts/inspect-database-schema.sql`](file:///c:/Users/Astik/school-app/scripts/inspect-database-schema.sql), and inspect your existing columns, constraints, and policies.

---

## 3. SAFE SEQUENTIAL STAGING EXECUTION RUNBOOK

Execute the following migrations in your Supabase project in the exact order specified below:

### Step 3.1: Open Supabase SQL Editor
1. Log in to [Supabase Dashboard](https://supabase.com/dashboard).
2. Select your staging project.
3. In the left navigation, click **SQL Editor**, then click **New Query**.

### Step 3.2: Execute Migration 21 (Financial & Base Security Hardening)
1. Open [`supabase/migrations/21_security_and_financial_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/21_security_and_financial_hardening.sql).
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run** (or press `Ctrl+Enter`).
4. Verify the output message: `Success. No rows returned`.

### Step 3.3: Execute Migration 22 (Maker-Checker & RLS Hardening)
1. Open [`supabase/migrations/22_phase2_security_and_rls_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/22_phase2_security_and_rls_hardening.sql).
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run**.
4. Verify the output message: `Success. No rows returned`.

### Step 3.4: Execute Migration 23 (Sales Readiness & Subscriptions)
1. Open [`supabase/migrations/23_sales_readiness_and_subscription_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/23_sales_readiness_and_subscription_hardening.sql).
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run**.
4. Verify the output message: `Success. No rows returned`.

---

## 4. EXECUTABLE DATABASE VALIDATION

Run the automated PostgreSQL verification script in Supabase SQL Editor:

1. In **Supabase SQL Editor**, open a **New Query**.
2. Open [`tests/staging-database-verification.sql`](file:///c:/Users/Astik/school-app/tests/staging-database-verification.sql).
3. Copy all lines into the query editor and click **Run**.
4. Confirm that the execution log completes with:
   ```text
   NOTICE: STAGE 1: VERIFYING MASTER PROVISIONING PERMISSIONS REVOCATION
   NOTICE: SUCCESS: All Master Provisioning RPCs are strictly isolated to service_role.
   NOTICE: STAGE 2: SETUP ISOLATED TEST FIXTURES (ALPHA & BETA SCHOOLS)
   NOTICE: SUCCESS: Test fixtures initialized for all 6 canonical roles and 2 schools.
   NOTICE: STAGE 3: VERIFYING CROSS-TENANT DATA ISOLATION (AS AUTHENTICATED ROLE)
   NOTICE: SUCCESS: RLS strictly blocks cross-tenant access to fee ledgers and profiles.
   NOTICE: STAGE 4: VERIFYING MAKER-CHECKER REVERSALS & SELF-APPROVAL BLOCKS
   NOTICE: VERIFIED: Step 1 (Maker) - Reversal request submitted with ID ...
   NOTICE: VERIFIED: Step 2 - Maker self-approval strictly rejected
   NOTICE: VERIFIED: Step 3 - Cross-tenant approval strictly rejected
   NOTICE: VERIFIED: Step 4 (Checker) - Principal approved reversal. Credit Note created and original marked reversed.
   NOTICE: VERIFIED: Step 5 - Direct reversal without independent maker request strictly rejected
   NOTICE: STAGE 5: VERIFYING PROFILE PRIVILEGE ESCALATION BLOCKS (INSERT & UPDATE)
   NOTICE: VERIFIED: 5.1 - Student profile privilege escalation on UPDATE strictly rejected by database trigger.
   NOTICE: VERIFIED: 5.2 - Non-administrative profile creation on INSERT strictly rejected by database policy & trigger.
   NOTICE: VERIFIED: 5.3 - Cross-tenant profile migration strictly rejected.
   NOTICE: STAGE 6: VERIFYING PDF QUEUE TENANT ISOLATION
   NOTICE: VERIFIED: Cross-tenant PDF queue lease claim strictly rejected.
   NOTICE: STAGE 7: VERIFYING AUDIT LOG IMMUTABILITY & REJECTION OF MODIFICATIONS
   NOTICE: VERIFIED: audit_logs table is immutable. Modifications and deletions strictly rejected.
   NOTICE: STAGE 8: VERIFYING PAYMENT ORDER ISOLATION
   NOTICE: VERIFIED: Payment orders are strictly tenant-isolated and customer-restricted.
   NOTICE: ALL 8 STAGING VERIFICATION TEST SUITES PASSED SUCCESSFULLY!
   NOTICE: ROLLING BACK TRANSACTION TO LEAVE STAGING ENVIRONMENT PRISTINE.
   ```
   *(Note: The verification script runs inside an explicit `BEGIN ... ROLLBACK;` block, leaving your staging database completely clean).*

---

## 5. SUPABASE AUTH (`auth.users`) ADMINISTRATOR ONBOARDING

When a school is provisioned via `/master-setup`, its application profile is created in `public.profiles`. In Supabase architecture, password login through GoTrue requires creating an authenticated user in `auth.users`:

### Step 5.1: Create Admin in Supabase Auth (via Dashboard)
1. Go to **Authentication** -> **Users** -> **Add User** -> **Create User**.
2. Enter the administrator's email (e.g., `gw-01.hod-01@academicos.internal`).
3. Set a temporary password and click **Create User**.
4. Set User Metadata / App Metadata:
   ```json
   {
     "school_id": "GW-01",
     "role": "HOD"
   }
   ```

### Step 5.2: Automated Script (Optional Node.js)
```javascript
import { createClient } from "@supabase/supabase-js";
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

await supabase.auth.admin.createUser({
  email: "gw-01.hod-01@academicos.internal",
  password: "SecurePassword123!",
  email_confirm: true,
  app_metadata: { school_id: "GW-01", role: "HOD" },
});
```

---

## 6. VERCEL ENVIRONMENT VARIABLES CONFIGURATION

In your [Vercel Project Settings](https://vercel.com) under **Environment Variables**, configure the following keys:

| Variable Name | Environment Scope | Secret? | Source / Description |
| :--- | :--- | :--- | :--- |
| `VITE_SUPABASE_URL` | Production, Preview | No | Supabase Dashboard -> Project Settings -> API -> Project URL |
| `VITE_SUPABASE_ANON_KEY` | Production, Preview | No | Supabase Dashboard -> Project Settings -> API -> `anon` public key |
| `SUPABASE_SERVICE_ROLE_KEY` | Production, Preview | **YES** | Supabase Dashboard -> Project Settings -> API -> `service_role` secret key |
| `VITE_RAZORPAY_KEY_ID` | Production, Preview | No | Razorpay Dashboard -> Settings -> API Keys (`rzp_test_...` or `rzp_live_...`) |
| `RAZORPAY_KEY_ID` | Production, Preview | No | Same value as `VITE_RAZORPAY_KEY_ID` (used by serverless API) |
| `RAZORPAY_KEY_SECRET` | Production, Preview | **YES** | Razorpay Dashboard -> Settings -> API Keys -> Key Secret |
| `RAZORPAY_WEBHOOK_SECRET` | Production, Preview | **YES** | Webhook secret configured in Razorpay Webhooks dashboard |
| `MASTER_SETUP_KEY` | Production, Preview | **YES** | Custom passkey (min 20 characters) for unlocking `/master-setup` |
| `MASTER_TOKEN_SECRET` | Production, Preview | **YES** | 64-char hex string (generate via `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`) |
| `BIOMETRIC_DEVICE_SECRET`| Production, Preview | **YES** | Shared secret for biometric turnstile hardware |
| `VITE_SENTRY_DSN` | Production, Preview | No | Sentry.io Client Key (DSN) for error reporting |

After updating environment variables, click **Deployments** -> **Redeploy** on the latest commit.

---

## 7. SAFE ROLLBACK PROCEDURE

If rollback is ever required:
1. Open **Supabase SQL Editor** -> **New Query**.
2. Open [`supabase/migrations/rollback_21_22_23.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/rollback_21_22_23.sql).
3. Paste the contents into the query editor and click **Run**.
4. Confirm:
   `NOTICE: SAFE ROLLBACK COMPLETED SUCCESSFULLY. DATABASE RESTORED SAFELY.`
5. **Changes that cannot safely be rolled back automatically:**
   - Table columns (`idempotency_key`, `original_entry_id`) and tables `payment_orders`, `fee_reversal_requests`, and `audit_logs` are explicitly preserved to prevent permanent data loss of transaction and audit history.
