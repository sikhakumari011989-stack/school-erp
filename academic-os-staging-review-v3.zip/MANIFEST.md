# ACADEMIC OS — STAGING REVIEW PACKAGE V3 MANIFEST
**Package Name:** `academic-os-staging-review-v3.zip`  
**Version:** 3.0.0 (Post-v3 Independent Review Remediation)  
**Date Generated:** 2026-11-05  
**Classification:** Confidential Staging Review & Security Evaluation Package  

---

## 1. Directory Structure & Included Files

```
academic-os-staging-review-v3.zip
├── migrations/
│   ├── 01_rls_policies.sql
│   ├── 02_pre_commercial_hardening.sql
│   ├── 03_rls_hardening.sql
│   ├── 18_auth_identity_and_profiles_rls_hardening.sql
│   ├── 19_master_setup_and_licensing.sql
│   ├── 20_class_test_marks.sql
│   ├── 21_security_and_financial_hardening.sql
│   ├── 22_phase2_security_and_rls_hardening.sql
│   └── 23_sales_readiness_and_subscription_hardening.sql
├── rollback/
│   └── rollback_21_22_23.sql
├── verification/
│   ├── staging-database-verification.sql
│   └── inspect-database-schema.sql
├── security-tests/
│   ├── security-authorization.test.js
│   └── class-test-marks.test.js
├── guides/
│   ├── OWNER_ACTIONS.md
│   ├── DEPLOYMENT_GUIDE.md
│   ├── SUPABASE_SETUP_GUIDE.md
│   ├── SCHOOL_ONBOARDING_GUIDE.md
│   └── BACKUP_AND_RECOVERY.md
├── reports/
│   ├── SALES_READINESS_REPORT.md
│   └── STAGING_TEST_RESULTS.md
├── MANIFEST.md
├── BUILD_AND_TEST_RESULTS.md
└── UNRESOLVED_ISSUES.md
```

---

## 2. Inventory of Changes in Package v3

1. **`migrations/21_security_and_financial_hardening.sql`:**
   - Native UUID primary key support for `fee_ledger.id`.
   - Fee reversal RPCs (`reverse_fee_entry`, `request_fee_reversal`, `approve_fee_reversal`) accept UUID entry identifiers.
   - Offsetting credit note generation creates native UUIDs via `gen_random_uuid()` and references original UUID in `original_entry_id`.
   - Reversal idempotency key scoped to tenant (`REV-<UUID>`).
   - Approver identity strictly derived from `auth.uid()` and session profile; client parameter `p_authorized_by` is discarded.
   - Maker-checker strictly enforced: direct reversal fails without an independent pending reversal request (`requester_id != auth.uid()`).
   - Audit logging: Explicit attachment of `trg_audit_fee_ledger`, `trg_audit_fee_reversal_requests`, and `trg_audit_profiles`.
   - `log_audit_event()` performs real `INSERT INTO public.audit_logs` and fails closed on error (`RAISE EXCEPTION`).
   - `audit_logs` table immutable: `INSERT`, `UPDATE`, `DELETE`, and `TRUNCATE` revoked from authenticated and anon roles.
   - User-settable session variables (`current_setting('app....')`) completely purged from helper functions.

2. **`migrations/22_phase2_security_and_rls_hardening.sql`:**
   - Canonical maker-checker RPCs operating over UUID primary keys.
   - `profiles_canonical_insert` strictly prohibits client-side insertion of executive/administrative roles (`PRIN`, `HOD`, `principal`, `trustee`).
   - Profile privilege escalation trigger (`protect_profile_privileged_columns`) attached to `BEFORE INSERT OR UPDATE ON public.profiles`.
   - Purged all `current_setting('app....')` bypasses from the profile trigger.
   - Prevents non-administrative callers from modifying `role`, `role_code`, `status`, or `school_id`.
   - Prevents cross-tenant profile migrations (`school_id` modifications strictly blocked).
   - Dynamic catalog sweep of unlisted permissive policies on core tables via `pg_policies`.
   - Preserved tenant lease isolation in `claim_next_pdf_job`.

3. **`migrations/23_sales_readiness_and_subscription_hardening.sql`:**
   - `provision_institutional_school` strictly handles UUID `school_id`, binding it cleanly to `profiles.school_id` (`uuid`).
   - Inter-school administrator overwrite protection prevents provisioning one school from modifying an existing administrator profile of another school.
   - Platform-owner checks strictly enforce `auth.role() = 'service_role'`.
   - `payment_orders` SELECT access restricted to authorized staff (`ACC`, `PRIN`, `HOD`) and customer student (`student_id = auth.uid()::text`).
   - Column-level grants revoke `raw_payload` from regular authenticated users.
   - Cryptographic verification in `/api/razorpay/verify-payment` validates payment order tenant ownership, amount, and idempotency.

4. **`rollback/rollback_21_22_23.sql`:**
   - Syntactically valid in Supabase SQL Editor (`RAISE NOTICE` enclosed in `DO $$ ... $$` blocks).
   - Drops audit triggers cleanly before dropping functions.
   - Preserves tenant isolation in `claim_next_pdf_job`.
   - Preserves all transaction and audit tables (`fee_ledger`, `fee_reversal_requests`, `audit_logs`, `payment_orders`).
   - Pre-rollback checks and post-rollback verification assertions.

5. **`verification/staging-database-verification.sql`:**
   - 100% executable in Supabase SQL Editor.
   - Native UUID support across fixtures (`a0000000-0000-0000-0000-000000000001`, `b0000000-0000-0000-0000-000000000002`, `f0000000-0000-0000-0000-000000000001`).
   - Standard PostgreSQL `DO $$ ... $$` blocks with zero psql metacommands.
   - Real authenticated role switching (`SET LOCAL ROLE authenticated`) and JWT claim mocking via `request.jwt.claims`.
   - 8 comprehensive test stages covering all 6 canonical roles, 2 schools, privilege escalation, maker-checker reversals, audit trigger verification, audit immutability, PDF queue isolation, and payment order isolation.
   - Wrapped in `BEGIN ... ROLLBACK;`.

6. **`verification/inspect-database-schema.sql`:**
   - Read-only schema inspection script for live Supabase databases.
