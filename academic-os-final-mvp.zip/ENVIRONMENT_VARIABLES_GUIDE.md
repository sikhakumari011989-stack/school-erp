# ACADEMIC OS — ENVIRONMENT VARIABLES & DEPLOYMENT RUNBOOK
**Classification:** Staging & Production Configuration Guide  
**Platform:** Vercel Serverless + Supabase PostgreSQL  
**Status:** MVP Final  

---

## 1. Environment Variables Matrix

Configure these keys in **Vercel Project Settings** -> **Environment Variables**:

| Variable Name | Required For | Secret? | Source / Description |
| :--- | :--- | :--- | :--- |
| `VITE_SUPABASE_URL` | Frontend & API | No | Supabase Dashboard -> Project Settings -> API -> Project URL |
| `VITE_SUPABASE_ANON_KEY` | Frontend | No | Supabase Dashboard -> Project Settings -> API -> Project API keys (`anon` / `public`) |
| `SUPABASE_SERVICE_ROLE_KEY` | Serverless APIs | **YES** | Supabase Dashboard -> Project Settings -> API -> `service_role` (Keep Confidential) |
| `VITE_RAZORPAY_KEY_ID` | Frontend Checkout | No | Razorpay Dashboard -> Account Settings -> API Keys (`rzp_test_...` or `rzp_live_...`) |
| `RAZORPAY_KEY_ID` | Serverless APIs | No | Same as `VITE_RAZORPAY_KEY_ID` |
| `RAZORPAY_KEY_SECRET` | Serverless APIs | **YES** | Razorpay Dashboard -> API Keys -> Key Secret (Used for HMAC verification) |
| `RAZORPAY_WEBHOOK_SECRET` | Serverless Webhooks | **YES** | Configured in Razorpay Webhooks Dashboard for `/api/razorpay/webhook` |
| `MASTER_SETUP_KEY` | Master Portal Setup | **YES** | Custom passkey (min 20 characters) for unlocking `/master-setup` |
| `MASTER_TOKEN_SECRET` | Master Operator Tokens | **YES** | 64-character hex string (generated via `crypto.randomBytes(32).toString('hex')`) |
| `BIOMETRIC_DEVICE_SECRET`| Biometric Hardware | **YES** | Pre-shared secret key between turnstiles and `/api/biometric/sync` |
| `VITE_SENTRY_DSN` | Telemetry & Observability | No | Sentry.io Client Key (DSN) for runtime error tracking |
| `VITE_WATI_API_ENDPOINT` | Outbound WhatsApp | No | *(Optional)* WATI Cloud API endpoint URL |
| `VITE_WATI_ACCESS_TOKEN` | Outbound WhatsApp | **YES** | *(Optional)* WATI API bearer token |
| `VITE_TWILIO_ACCOUNT_SID`| Outbound SMS | No | *(Optional)* Twilio Account SID |
| `VITE_TWILIO_AUTH_TOKEN` | Outbound SMS | **YES** | *(Optional)* Twilio Auth Token |
| `VITE_TWILIO_PHONE_NUMBER`| Outbound SMS | No | *(Optional)* Twilio sender phone number |

---

## 2. Generating Secure Master Secrets

Run this one-line Node command to generate cryptographic secrets for `MASTER_TOKEN_SECRET` and `BIOMETRIC_DEVICE_SECRET`:

```bash
node -e "console.log('Secret:', require('crypto').randomBytes(32).toString('hex'))"
```

---

## 3. Redeployment Steps on Vercel

1. In the Vercel Dashboard, navigate to **Settings** -> **Environment Variables**.
2. Add or update the variables listed above. Ensure **Production**, **Preview**, and **Development** checkboxes are selected as appropriate.
3. Go to **Deployments**.
4. On the latest commit, click the three-dots menu (`...`) and select **Redeploy**.
5. Ensure the build succeeds (Build command: `npm run build`, Output directory: `dist`).
