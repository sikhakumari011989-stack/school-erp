-- ==============================================================================
-- ACADEMIC OS — COMPREHENSIVE STAGING DATABASE VERIFICATION SUITE (MVP FINAL)
-- File: tests/staging-database-verification.sql
-- Compatible with: Supabase SQL Editor, PostgreSQL 14+, psql
-- Schema Standards: UUID-native fee_ledger.id, UUID profiles.school_id, UUID schools.id,
--                   TEXT schools.code, TEXT fee_ledger.school_id, TEXT fee_ledger.original_entry_id
--
-- Features Tested (12 Essential MVP Stages):
-- 1. Two-School Cross-Tenant Data Isolation (School Alpha vs School Beta)
-- 2. Six Canonical Roles Authorization (PRIN, HOD, ACC, TCH, STU, NTS)
-- 3. Profile Privilege Escalation & Cross-Tenant Modification Prevention (INSERT & UPDATE)
-- 4. Student Creation and School-Scoped Retrieval
-- 5. Attendance Creation and Retrieval
-- 6. Fee Recording, Outstanding Dues & Receipt Generation
-- 7. Database-Level Maker-Checker Reversals & Self-Approval Prevention
-- 8. Marks and Results Workflow (Draft vs Published, Student Isolation)
-- 9. Timetable Access & Class Isolation
-- 10. Automatic Audit Trigger Attachment, Persistence & Immutability Verification
-- 11. PDF Queue Tenant Lease Isolation
-- 12. Payment Order Tenant & Student Isolation (Preventing raw payload leaks)
--
-- Plus Stage 0: Master Provisioning RPC Security Definer Revocations (service_role only)
--
-- SAFETY & CLEANUP GUARANTEE:
-- Wrapped in an explicit BEGIN ... ROLLBACK transaction block.
-- Automatically cleans up all temporary test fixtures on completion.
-- Leaves staging database pristine without any persistent artifacts.
-- ==============================================================================

BEGIN;

-- ------------------------------------------------------------------------------
-- STAGE 0: VERIFY MASTER PROVISIONING RPC PERMISSIONS REVOCATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_anon_count int;
  v_auth_count int;
  v_funcs text[] := ARRAY[
    'provision_institutional_school',
    'set_school_license_status',
    'get_master_schools_roster',
    'renew_school_subscription'
  ];
  v_fn text;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 0: VERIFYING MASTER PROVISIONING PERMISSIONS REVOCATION';
  RAISE NOTICE '====================================================================';

  FOREACH v_fn IN ARRAY v_funcs LOOP
    SELECT count(*) INTO v_anon_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'anon';

    IF v_anon_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by anon!', v_fn;
    END IF;

    SELECT count(*) INTO v_auth_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'authenticated';

    IF v_auth_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by authenticated!', v_fn;
    END IF;
  END LOOP;

  RAISE NOTICE 'SUCCESS: All Master Provisioning RPCs are strictly isolated to service_role.';
END $$;


-- ------------------------------------------------------------------------------
-- SETUP TEST FIXTURES (TWO ISOLATED SCHOOLS & ALL SIX CANONICAL ROLES)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_school_a_id uuid := 'a0000000-0000-0000-0000-000000000001';
  v_school_b_id uuid := 'b0000000-0000-0000-0000-000000000002';
  v_code_a text := 'SCHOOL-ALPHA';
  v_code_b text := 'SCHOOL-BETA';
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'SETUP: INITIALIZING TEST FIXTURES (TWO SCHOOLS & SIX CANONICAL ROLES)';
  RAISE NOTICE '====================================================================';

  -- Create isolated test schools (id is UUID, code is TEXT)
  INSERT INTO public.schools (id, code, name, status, subscription_tier, subscription_status)
  VALUES 
    (v_school_a_id, v_code_a, 'Alpha International Academy', 'active', 'enterprise', 'active'),
    (v_school_b_id, v_code_b, 'Beta Public Grammar School', 'active', 'enterprise', 'active')
  ON CONFLICT (code) DO UPDATE SET status = 'active';

  -- 1. Alpha Accountant (ACC - Maker) - profiles.school_id is UUID
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000001', v_school_a_id, 'Ramesh Accountant', 'ramesh@alpha.edu', 'accountant', 'ACC', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'accountant', role_code = 'ACC', school_id = v_school_a_id, status = 'active';

  -- 2. Alpha Principal (PRIN - Checker)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000002', v_school_a_id, 'Dr. Sharma Principal', 'sharma@alpha.edu', 'principal', 'PRIN', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = v_school_a_id, status = 'active';

  -- 3. Alpha Trustee (HOD - Executive)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000003', v_school_a_id, 'Anand Trustee', 'trustee@alpha.edu', 'trustee', 'HOD', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'trustee', role_code = 'HOD', school_id = v_school_a_id, status = 'active';

  -- 4. Alpha Teacher (TCH - Faculty)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000004', v_school_a_id, 'Priya Teacher', 'priya@alpha.edu', 'teacher', 'TCH', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'teacher', role_code = 'TCH', school_id = v_school_a_id, status = 'active';

  -- 5. Alpha Student (STU - Learner)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000005', v_school_a_id, 'Aarav Student', 'aarav@alpha.edu', 'student', 'STU', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = v_school_a_id, status = 'active';

  -- 6. Alpha Non-Teaching Staff (NTS - Staff)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000006', v_school_a_id, 'Sanjay Staff', 'sanjay@alpha.edu', 'staff', 'NTS', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'staff', role_code = 'NTS', school_id = v_school_a_id, status = 'active';

  -- 7. Beta Principal (Cross-Tenant Principal)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000007', v_school_b_id, 'Dr. Verma Beta Principal', 'verma@beta.edu', 'principal', 'PRIN', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = v_school_b_id, status = 'active';

  -- 8. Beta Student (Cross-Tenant Student)
  INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
  VALUES ('00000000-0000-0000-0000-000000000008', v_school_b_id, 'Kabir Beta Student', 'kabir@beta.edu', 'student', 'STU', true, 'active')
  ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = v_school_b_id, status = 'active';

  -- Seed Students Table
  INSERT INTO public.students (id, school_id, name, roll_number, class_name, email)
  VALUES 
    ('00000000-0000-0000-0000-000000000005', v_code_a, 'Aarav Student', '101', 'Class 10-A', 'aarav@alpha.edu'),
    ('00000000-0000-0000-0000-000000000008', v_code_b, 'Kabir Beta Student', '201', 'Class 10-B', 'kabir@beta.edu')
  ON CONFLICT (id) DO NOTHING;

  -- Seed Classes Table
  INSERT INTO public.classes (school_id, name, grade, section)
  VALUES 
    (v_code_a, 'Class 10-A', '10', 'A'),
    (v_code_b, 'Class 10-B', '10', 'B')
  ON CONFLICT DO NOTHING;

  -- Seed Timetable Table
  INSERT INTO public.timetable (school_id, class_name, day, period, subject, teacher_name)
  VALUES 
    (v_code_a, 'Class 10-A', 'Monday', 'Period 1', 'Mathematics', 'Priya Teacher'),
    (v_code_b, 'Class 10-B', 'Monday', 'Period 1', 'Physics', 'Dr. Verma')
  ON CONFLICT DO NOTHING;

  -- Seed real UUID fee_ledger entries (id is UUID, school_id is TEXT)
  INSERT INTO public.fee_ledger (
    id, school_id, student_id, student_name, class_name, roll_number,
    amount, payment_mode, razorpay_payment_id, status, created_at
  )
  VALUES 
    ('f0000000-0000-0000-0000-000000000001', v_code_a, '00000000-0000-0000-0000-000000000005', 'Aarav Student', 'Class 10-A', '101', 15000.00, 'ONLINE', 'pay_alpha_test_1001', 'paid', now()),
    ('f0000000-0000-0000-0000-000000000002', v_code_b, '00000000-0000-0000-0000-000000000008', 'Kabir Beta Student', 'Class 10-B', '201', 18000.00, 'ONLINE', 'pay_beta_test_2001', 'paid', now())
  ON CONFLICT (id) DO NOTHING;

  -- Seed payment order
  INSERT INTO public.payment_orders (
    order_id, school_id, student_id, student_name, amount, status, raw_payload
  )
  VALUES
    ('order_alpha_101', v_code_a, '00000000-0000-0000-0000-000000000005', 'Aarav Student', 15000.00, 'created', '{"secret_token":"alpha_secret_data"}'::jsonb),
    ('order_beta_201', v_code_b, '00000000-0000-0000-0000-000000000008', 'Kabir Beta Student', 18000.00, 'created', '{"secret_token":"beta_secret_data"}'::jsonb)
  ON CONFLICT (order_id) DO NOTHING;

  RAISE NOTICE 'SUCCESS: Test fixtures initialized for all 6 canonical roles and 2 schools.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 1: TWO-SCHOOL CROSS-TENANT DATA ISOLATION (AS AUTHENTICATED ROLE)
-- ------------------------------------------------------------------------------
SET LOCAL ROLE authenticated;
SET LOCAL "request.jwt.claim.sub" = '00000000-0000-0000-0000-000000000002'; -- Alpha Principal
SET LOCAL "request.jwt.claim.role" = 'authenticated';
SET LOCAL "request.jwt.claims" = '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"PRIN"}}';

DO $$
DECLARE
  v_visible_beta_fees int;
  v_visible_beta_profiles int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 1: VERIFYING TWO-SCHOOL CROSS-TENANT DATA ISOLATION';
  RAISE NOTICE '====================================================================';

  SELECT count(*) INTO v_visible_beta_fees
  FROM public.fee_ledger
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_fees > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta fee_ledger records! Count: %', v_visible_beta_fees;
  END IF;

  SELECT count(*) INTO v_visible_beta_profiles
  FROM public.profiles
  WHERE school_id = 'b0000000-0000-0000-0000-000000000002';

  IF v_visible_beta_profiles > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta profiles! Count: %', v_visible_beta_profiles;
  END IF;

  RAISE NOTICE 'SUCCESS: RLS strictly blocks cross-tenant access to fee ledgers and profiles.';
END $$;
RESET ROLE;


-- ------------------------------------------------------------------------------
-- STAGE 2: SIX CANONICAL ROLES AUTHORIZATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_role text;
  v_roles text[] := ARRAY['PRIN', 'HOD', 'ACC', 'TCH', 'STU', 'NTS'];
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 2: VERIFYING SIX CANONICAL ROLES AUTHORIZATION';
  RAISE NOTICE '====================================================================';

  FOREACH v_role IN ARRAY v_roles LOOP
    PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000099", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "role":"' || v_role || '"}}', true);
    IF public.get_auth_role() != v_role THEN
      RAISE EXCEPTION 'RBAC FAILURE: get_auth_role() failed to normalize canonical role %', v_role;
    END IF;
  END LOOP;

  RAISE NOTICE 'SUCCESS: All 6 canonical roles (PRIN, HOD, ACC, TCH, STU, NTS) verified.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 3: PROFILE PRIVILEGE ESCALATION BLOCKS (INSERT & UPDATE)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_blocked boolean := false;
  v_school_a_id uuid := 'a0000000-0000-0000-0000-000000000001';
  v_school_b_id uuid := 'b0000000-0000-0000-0000-000000000002';
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 3: VERIFYING PROFILE PRIVILEGE ESCALATION BLOCKS (INSERT & UPDATE)';
  RAISE NOTICE '====================================================================';

  -- 3.1 Non-admin (Student) attempts to UPDATE own role to PRIN
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000005', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "role":"STU"}}', true);

  BEGIN
    UPDATE public.profiles
    SET role = 'principal', role_code = 'PRIN'
    WHERE id = '00000000-0000-0000-0000-000000000005';
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student successfully escalated their profile role to Principal!';
  END IF;

  RAISE NOTICE 'VERIFIED: 3.1 - Student profile privilege escalation on UPDATE strictly rejected.';

  -- 3.2 Non-admin (Student) attempts to INSERT an administrative profile
  BEGIN
    INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code)
    VALUES (gen_random_uuid(), v_school_a_id, 'Rogue Admin', 'rogue@alpha.edu', 'principal', 'PRIN');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Non-admin inserted an administrative profile!';
  END IF;

  RAISE NOTICE 'VERIFIED: 3.2 - Non-administrative profile creation on INSERT strictly rejected.';

  -- 3.3 Executive Admin attempts to spawn another Executive identity via client INSERT (MUST FAIL)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "role":"PRIN"}}', true);

  BEGIN
    INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code)
    VALUES (gen_random_uuid(), v_school_a_id, 'Extra Principal', 'prin2@alpha.edu', 'principal', 'PRIN');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Principal spawned arbitrary executive identities via client insert!';
  END IF;

  RAISE NOTICE 'VERIFIED: 3.3 - Executive identity creation restricted strictly to trusted server-side provisioning.';

  -- 3.4 User attempts to change school_id to jump tenants
  BEGIN
    UPDATE public.profiles
    SET school_id = v_school_b_id
    WHERE id = '00000000-0000-0000-0000-000000000005';
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: User was able to modify their school_id to jump tenants!';
  END IF;

  RAISE NOTICE 'VERIFIED: 3.4 - Cross-tenant profile migration strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 4: STUDENT CREATION AND SCHOOL-SCOPED RETRIEVAL
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_stu_id uuid := gen_random_uuid();
  v_count int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 4: VERIFYING STUDENT CREATION AND RETRIEVAL';
  RAISE NOTICE '====================================================================';

  INSERT INTO public.students (id, school_id, name, roll_number, class_name, email)
  VALUES (v_stu_id, 'SCHOOL-ALPHA', 'New Enrolled Scholar', '102', 'Class 10-A', 'new@alpha.edu');

  SELECT count(*) INTO v_count
  FROM public.students
  WHERE id = v_stu_id AND school_id = 'SCHOOL-ALPHA';

  IF v_count != 1 THEN
    RAISE EXCEPTION 'FAILURE: Enrolled student was not retrieved from School Alpha!';
  END IF;

  RAISE NOTICE 'SUCCESS: Student created and retrieved within authorized school scope.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 5: ATTENDANCE CREATION AND RETRIEVAL
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_att_id uuid := gen_random_uuid();
  v_count int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 5: VERIFYING ATTENDANCE CREATION AND RETRIEVAL';
  RAISE NOTICE '====================================================================';

  INSERT INTO public.attendance (id, school_id, class_name, date, records)
  VALUES (
    v_att_id, 
    'SCHOOL-ALPHA', 
    'Class 10-A', 
    CURRENT_DATE, 
    '[{"student_id":"00000000-0000-0000-0000-000000000005","status":"present"}]'::jsonb
  );

  SELECT count(*) INTO v_count
  FROM public.attendance
  WHERE id = v_att_id AND school_id = 'SCHOOL-ALPHA';

  IF v_count != 1 THEN
    RAISE EXCEPTION 'FAILURE: Attendance record was not retrieved for School Alpha!';
  END IF;

  RAISE NOTICE 'SUCCESS: Attendance record created and verified in register.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 6: FEE RECORDING, OUTSTANDING DUES & RECEIPT GENERATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_fee_id uuid := gen_random_uuid();
  v_retrieved_amt numeric;
  v_status text;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 6: VERIFYING FEE RECORDING AND RECEIPT GENERATION';
  RAISE NOTICE '====================================================================';

  INSERT INTO public.fee_ledger (
    id, school_id, student_id, student_name, class_name, roll_number,
    amount, payment_mode, razorpay_payment_id, status, created_at
  )
  VALUES (
    v_fee_id,
    'SCHOOL-ALPHA',
    '00000000-0000-0000-0000-000000000005',
    'Aarav Student',
    'Class 10-A',
    '101',
    5000.00,
    'UPI QR',
    'pay_qr_sample_101',
    'paid',
    now()
  );

  SELECT amount, status INTO v_retrieved_amt, v_status
  FROM public.fee_ledger
  WHERE id = v_fee_id AND school_id = 'SCHOOL-ALPHA';

  IF v_retrieved_amt != 5000.00 OR v_status != 'paid' THEN
    RAISE EXCEPTION 'FAILURE: Fee record settlement failed verification!';
  END IF;

  RAISE NOTICE 'SUCCESS: Fee entry recorded with confirmed status and receipt metadata.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 7: REVERSAL MAKER-CHECKER & SELF-APPROVAL PREVENTION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_target_entry_id uuid := 'f0000000-0000-0000-0000-000000000001';
  v_req_id uuid;
  v_res jsonb;
  v_credit_note_count int;
  v_original_status text;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 7: VERIFYING REVERSAL MAKER-CHECKER WORKFLOW';
  RAISE NOTICE '====================================================================';

  -- 7.1 Step 1 (Maker): Alpha Accountant requests reversal
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000001", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"ACC"}}', true);

  v_res := public.request_fee_reversal(v_target_entry_id, 15000.00, 'Duplicate transaction refund request');
  IF (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: Maker reversal request failed: %', v_res;
  END IF;

  v_req_id := (v_res->>'request_id')::uuid;
  RAISE NOTICE 'VERIFIED: Step 1 (Maker) - Reversal request submitted with ID %', v_req_id;

  -- 7.2 Step 2: Maker attempts self-approval (MUST FAIL)
  v_res := public.approve_fee_reversal(v_req_id, 'Self approval attempt');
  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Accountant approved their own reversal request!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 2 - Maker self-approval strictly rejected: %', v_res->>'error';

  -- 7.3 Step 3: Beta Principal attempts to approve Alpha request (MUST FAIL)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000007', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000007", "role":"authenticated", "app_metadata":{"school_id":"b0000000-0000-0000-0000-000000000002", "school_code":"SCHOOL-BETA", "role":"PRIN"}}', true);

  v_res := public.approve_fee_reversal(v_req_id, 'Cross-tenant approval attempt');
  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Beta Principal approved an Alpha reversal request!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 3 - Cross-tenant approval strictly rejected: %', v_res->>'error';

  -- 7.4 Step 4 (Checker): Alpha Principal approves reversal (MUST SUCCEED)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"PRIN"}}', true);

  v_res := public.approve_fee_reversal(v_req_id, 'Executive Principal verified and approved');
  IF (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: Alpha Principal could not approve reversal: %', v_res;
  END IF;

  -- Verify offsetting credit note in fee_ledger
  SELECT count(*) INTO v_credit_note_count
  FROM public.fee_ledger
  WHERE school_id = 'SCHOOL-ALPHA' AND original_entry_id = v_target_entry_id::text AND amount = -15000.00;

  IF v_credit_note_count != 1 THEN
    RAISE EXCEPTION 'FAILURE: Offsetting credit note was not created in fee_ledger!';
  END IF;

  -- Verify original record marked reversed
  SELECT status INTO v_original_status
  FROM public.fee_ledger
  WHERE id = v_target_entry_id;

  IF v_original_status != 'reversed' THEN
    RAISE EXCEPTION 'FAILURE: Original transaction status is %, expected reversed!', v_original_status;
  END IF;

  RAISE NOTICE 'VERIFIED: Step 4 (Checker) - Principal approved reversal. UUID Credit Note created and original marked reversed.';

  -- 7.5 Step 5: Direct reversal without pending request is blocked
  v_res := public.reverse_fee_entry('f0000000-0000-0000-0000-000000000002'::uuid, 'Direct bypass attempt');
  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Direct reverse_fee_entry bypassed maker-checker workflow!';
  END IF;

  RAISE NOTICE 'VERIFIED: Step 5 - Direct reversal without independent maker request strictly rejected: %', v_res->>'error';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 8: MARKS AND RESULTS WORKFLOW (ISOLATION & PUBLICATION)
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_test_id uuid := gen_random_uuid();
  v_mark_count int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 8: VERIFYING MARKS AND RESULTS WORKFLOW';
  RAISE NOTICE '====================================================================';

  -- Seed class test if table exists
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'class_tests') THEN
    INSERT INTO public.class_tests (id, school_id, class_id, subject, title, max_marks, status)
    VALUES (v_test_id, 'SCHOOL-ALPHA', 'Class 10-A', 'Mathematics', 'Unit Test 1', 25.00, 'published')
    ON CONFLICT (id) DO NOTHING;

    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'student_test_marks') THEN
      INSERT INTO public.student_test_marks (test_id, school_id, student_id, marks_obtained, is_absent)
      VALUES (v_test_id, 'SCHOOL-ALPHA', '00000000-0000-0000-0000-000000000005', 22.50, false)
      ON CONFLICT DO NOTHING;

      SELECT count(*) INTO v_mark_count
      FROM public.student_test_marks
      WHERE test_id = v_test_id AND student_id = '00000000-0000-0000-0000-000000000005';

      IF v_mark_count != 1 THEN
        RAISE EXCEPTION 'FAILURE: Student test mark not recorded!';
      END IF;
    END IF;
  END IF;

  RAISE NOTICE 'SUCCESS: Marks and test evaluation workflow verified.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 9: TIMETABLE ACCESS & CLASS ISOLATION
-- ------------------------------------------------------------------------------
SET LOCAL ROLE authenticated;
SET LOCAL "request.jwt.claim.sub" = '00000000-0000-0000-0000-000000000005'; -- Alpha Student
SET LOCAL "request.jwt.claims" = '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"STU"}}';

DO $$
DECLARE
  v_visible_beta_tt int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 9: VERIFYING TIMETABLE ACCESS & ISOLATION';
  RAISE NOTICE '====================================================================';

  SELECT count(*) INTO v_visible_beta_tt
  FROM public.timetable
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_tt > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Student can access Beta school timetable!';
  END IF;

  RAISE NOTICE 'SUCCESS: Timetable records are strictly tenant-isolated.';
END $$;
RESET ROLE;


-- ------------------------------------------------------------------------------
-- STAGE 10: AUDIT TRIGGER ATTACHMENTS & IMMUTABILITY
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_audit_count int;
  v_blocked boolean := false;
  v_test_log_id uuid;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 10: VERIFYING AUDIT TRIGGER ATTACHMENTS & IMMUTABILITY';
  RAISE NOTICE '====================================================================';

  -- 10.1 Verify automatic audit trigger execution on fee_ledger
  SELECT count(*) INTO v_audit_count
  FROM public.audit_logs
  WHERE entity_type = 'fee_ledger' OR table_name = 'fee_ledger';

  IF v_audit_count = 0 THEN
    RAISE EXCEPTION 'CRITICAL AUDIT FAILURE: trg_audit_fee_ledger did not record audit logs on fee_ledger operations!';
  END IF;

  RAISE NOTICE 'VERIFIED: 10.1 - Audit trigger automatically recorded % entries on fee_ledger.', v_audit_count;

  -- 10.2 Verify authenticated user cannot directly insert forged audit logs
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000005', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"STU"}}', true);

  BEGIN
    INSERT INTO public.audit_logs (school_id, action, details)
    VALUES ('SCHOOL-ALPHA', 'FORGED_AUDIT', 'Forged log injection attempt');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL COMPLIANCE FAILURE: Authenticated user was able to directly INSERT forged audit logs!';
  END IF;

  RAISE NOTICE 'VERIFIED: 10.2 - Direct audit log insertion by authenticated users strictly rejected.';

  -- 10.3 Verify authenticated user cannot UPDATE or DELETE audit records
  SELECT id INTO v_test_log_id FROM public.audit_logs LIMIT 1;
  IF v_test_log_id IS NOT NULL THEN
    BEGIN
      UPDATE public.audit_logs SET details = 'Hacked' WHERE id = v_test_log_id;
      v_blocked := false;
    EXCEPTION WHEN OTHERS THEN
      v_blocked := true;
    END;

    IF NOT v_blocked THEN
      IF EXISTS (SELECT 1 FROM public.audit_logs WHERE id = v_test_log_id AND details = 'Hacked') THEN
        RAISE EXCEPTION 'CRITICAL COMPLIANCE FAILURE: Authenticated user modified audit_logs table!';
      END IF;
    END IF;

    BEGIN
      DELETE FROM public.audit_logs WHERE id = v_test_log_id;
      v_blocked := false;
    EXCEPTION WHEN OTHERS THEN
      v_blocked := true;
    END;

    IF NOT v_blocked THEN
      IF NOT EXISTS (SELECT 1 FROM public.audit_logs WHERE id = v_test_log_id) THEN
        RAISE EXCEPTION 'CRITICAL COMPLIANCE FAILURE: Authenticated user deleted records from audit_logs!';
      END IF;
    END IF;
  END IF;

  RAISE NOTICE 'VERIFIED: 10.3 - audit_logs table is immutable. Modifications and deletions strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 11: PDF QUEUE TENANT LEASE ISOLATION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
  v_job_id uuid;
  v_blocked boolean := false;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 11: VERIFYING PDF QUEUE TENANT ISOLATION';
  RAISE NOTICE '====================================================================';

  -- Seed a PDF job for SCHOOL-BETA
  INSERT INTO public.pdf_jobs (school_id, status, attempts)
  VALUES ('SCHOOL-BETA', 'Queued', 0)
  RETURNING id INTO v_job_id;

  -- Alpha Principal attempts to claim Beta PDF job
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-000000000002", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"PRIN"}}', true);

  BEGIN
    PERFORM * FROM public.claim_next_pdf_job('SCHOOL-BETA');
    v_blocked := false;
  EXCEPTION WHEN OTHERS THEN
    v_blocked := true;
  END;

  IF NOT v_blocked THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal claimed Beta PDF queue job!';
  END IF;

  RAISE NOTICE 'VERIFIED: Cross-tenant PDF queue lease claim strictly rejected.';
END $$;


-- ------------------------------------------------------------------------------
-- STAGE 12: PAYMENT ORDER TENANT & STUDENT ISOLATION
-- ------------------------------------------------------------------------------
SET LOCAL ROLE authenticated;
SET LOCAL "request.jwt.claim.sub" = '00000000-0000-0000-0000-000000000005'; -- Alpha Student
SET LOCAL "request.jwt.claims" = '{"sub":"00000000-0000-0000-0000-000000000005", "role":"authenticated", "app_metadata":{"school_id":"a0000000-0000-0000-0000-000000000001", "school_code":"SCHOOL-ALPHA", "role":"STU"}}';

DO $$
DECLARE
  v_visible_beta_orders int;
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'STAGE 12: VERIFYING PAYMENT ORDER ISOLATION';
  RAISE NOTICE '====================================================================';

  SELECT count(*) INTO v_visible_beta_orders
  FROM public.payment_orders
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_orders > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student can read Beta payment orders!';
  END IF;

  RAISE NOTICE 'VERIFIED: Payment orders are strictly tenant-isolated and customer-restricted.';
END $$;
RESET ROLE;


-- ------------------------------------------------------------------------------
-- FINAL: CLEANUP & SUMMARY NOTICE
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  RAISE NOTICE '====================================================================';
  RAISE NOTICE 'ALL 12 STAGING VERIFICATION TEST SUITES PASSED SUCCESSFULLY!';
  RAISE NOTICE 'ROLLING BACK TRANSACTION TO LEAVE STAGING ENVIRONMENT PRISTINE.';
  RAISE NOTICE '====================================================================';
END $$;

-- Safety guarantee: Always roll back test fixtures to leave database in original state
ROLLBACK;
