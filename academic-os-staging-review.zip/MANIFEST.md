# ACADEMIC OS — STAGING REVIEW PACKAGE MANIFEST
**Package Name:** `academic-os-staging-review.zip`  
**Generated At:** 2026-11-04  
**Classification:** Complete Independent Review Deliverable  

---

## Package Directory Structure & File Mapping

| Archive Path | Original Repository Path | Category | Purpose / Description |
| :--- | :--- | :--- | :--- |
| `migrations/21_security_and_financial_hardening.sql` | `supabase/migrations/21_security_and_financial_hardening.sql` | Migrations | Migration 21: Maker-checker base schema, audit_logs table, hardened reverse_fee_entry |
| `migrations/22_phase2_security_and_rls_hardening.sql` | `supabase/migrations/22_phase2_security_and_rls_hardening.sql` | Migrations | Migration 22: Maker-checker RPC pipeline, profile column protection trigger, RLS deconfliction |
| `migrations/23_sales_readiness_and_subscription_hardening.sql` | `supabase/migrations/23_sales_readiness_and_subscription_hardening.sql` | Migrations | Migration 23: Payment orders table, admin profile auto-provisioning, renew_school_subscription RPC |
| `migrations/01_rls_policies.sql` | `supabase/migrations/01_rls_policies.sql` | Migrations | Baseline Schema: Core table definitions (schools, profiles, fee_ledger with text ID) |
| `migrations/18_auth_identity_and_profiles_rls_hardening.sql` | `supabase/migrations/18_auth_identity_and_profiles_rls_hardening.sql` | Migrations | Auth & RBAC: Canonical role extractor `get_auth_role()` and tenant extractor `get_current_tenant_id()` |
| `migrations/19_master_setup_and_licensing.sql` | `supabase/migrations/19_master_setup_and_licensing.sql` | Migrations | Licensing: `school_licenses`, `school_license_audit_logs`, baseline provisioning engine |
| `migrations/20_class_test_marks.sql` | `supabase/migrations/20_class_test_marks.sql` | Migrations | Academics: Class test marks schema, draft/publish lifecycle, and student marks isolation |
| `rollback/rollback_21_22_23.sql` | `supabase/migrations/rollback_21_22_23.sql` | Rollback | Safe, non-destructive rollback script preserving payment orders, reversals, and audit logs |
| `verification/staging-database-verification.sql` | `tests/staging-database-verification.sql` | Verification | Complete 9-stage executable PostgreSQL verification suite testing tenant isolation, RBAC, and reversals |
| `security-tests/security-authorization.test.js` | `tests/security-authorization.test.js` | Security Tests | Automated Node.js test suite for RBAC, token security, fee reversal parameters, and webhook signatures |
| `security-tests/class-test-marks.test.js` | `tests/class-test-marks.test.js` | Security Tests | Automated Node.js test suite for class test marks entry, draft protection, and marks isolation |
| `security-tests/institutional-loop.spec.js` | `tests/e2e/institutional-loop.spec.js` | Security Tests | End-to-end institutional workflow verification specification |
| `guides/OWNER_ACTIONS.md` | `OWNER_ACTIONS.md` | Guides | Staging execution runbook, sequential migration checklist, and expected verification logs |
| `guides/DEPLOYMENT_GUIDE.md` | `DEPLOYMENT_GUIDE.md` | Guides | Full production & staging deployment manual for Supabase and Vercel |
| `guides/SUPABASE_SETUP_GUIDE.md` | `SUPABASE_SETUP_GUIDE.md` | Guides | Step-by-step setup guide for Supabase project, storage buckets, and RLS |
| `guides/SCHOOL_ONBOARDING_GUIDE.md` | `SCHOOL_ONBOARDING_GUIDE.md` | Guides | Operations guide for onboarding new institutions via Master Setup Gateway |
| `guides/ADMIN_USER_GUIDE.md` | `ADMIN_USER_GUIDE.md` | Guides | Role-based operational manual for Principals, Trustees, and Accountants |
| `guides/BACKUP_AND_RECOVERY.md` | `BACKUP_AND_RECOVERY.md` | Guides | Institutional disaster recovery, PITR configuration, and backup runbooks |
| `reports/SALES_READINESS_REPORT.md` | `SALES_READINESS_REPORT.md` | Reports | Comprehensive architectural audit report assessing sales readiness across 19 dimensions |
| `reports/STAGING_TEST_RESULTS.md` | `STAGING_TEST_RESULTS.md` | Reports | Detailed test result catalog covering all automated and staging test suites |
| `MANIFEST.md` | `MANIFEST.md` | Root | Package manifest documenting all included files, original paths, and purposes |
| `BUILD_AND_TEST_RESULTS.md` | `BUILD_AND_TEST_RESULTS.md` | Root | Detailed log of automated test suite (81 tests) and Vite production build |
| `UNRESOLVED_ISSUES.md` | `UNRESOLVED_ISSUES.md` | Root | Transparent disclosure of operational prerequisites, Supabase Auth vs profiles, and gateway keys |

