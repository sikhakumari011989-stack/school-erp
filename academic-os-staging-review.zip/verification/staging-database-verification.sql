-- ==============================================================================
-- ACADEMIC OS — COMPREHENSIVE STAGING DATABASE VERIFICATION SUITE
-- File: tests/staging-database-verification.sql
-- Purpose: Complete, executable PostgreSQL validation suite for Academic OS.
--
-- Tests Covered:
-- 1. Master Provisioning RPC Security Definer Revocations (service_role only)
-- 2. Test Fixture Setup (Isolated Schools & Canonical Roles)
-- 3. Cross-Tenant Data Isolation Between Institutions
-- 4. Database-Level Maker-Checker Reversals & Self-Approval Prevention
-- 5. Profile Privilege Escalation & Cross-Tenant Alteration Prevention
-- 6. PDF Queue Tenant Lease Isolation
-- 7. Audit Log Recording & Immutable Storage
-- 8. Payment Order Tenant Isolation
-- 9. Permissive RLS Policy Deconfliction & Leaky Rule Elimination
--
-- SAFETY GUARANTEE:
-- Wrapped in an explicit BEGIN ... ROLLBACK transaction.
-- Leaves staging and production tables completely pristine.
-- ==============================================================================

\set ON_ERROR_STOP on

BEGIN;

RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 1: VERIFYING MASTER PROVISIONING PERMISSIONS REVOCATION';
RAISE NOTICE '====================================================================';

DO $$
DECLARE
  v_anon_count int;
  v_auth_count int;
  v_funcs text[] := ARRAY['provision_institutional_school', 'set_school_license_status', 'get_master_schools_roster', 'renew_school_subscription'];
  v_fn text;
BEGIN
  FOREACH v_fn IN ARRAY v_funcs LOOP
    SELECT count(*) INTO v_anon_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'anon';

    IF v_anon_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by anon!', v_fn;
    END IF;

    SELECT count(*) INTO v_auth_count
    FROM information_schema.routine_privileges
    WHERE routine_name = v_fn AND grantee = 'authenticated';

    IF v_auth_count > 0 THEN
      RAISE EXCEPTION 'SECURITY FAILURE: Function % is still executable by authenticated!', v_fn;
    END IF;
  END LOOP;

  RAISE NOTICE 'SUCCESS: All Master Provisioning RPCs are strictly isolated to service_role.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 2: SETUP ISOLATED TEST FIXTURES (ALPHA & BETA SCHOOLS)';
RAISE NOTICE '====================================================================';

-- Ensure prerequisite columns exist on public.profiles
ALTER TABLE IF EXISTS public.profiles
  ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';

-- Create isolated test schools
INSERT INTO public.schools (id, code, name, status, subscription_tier, subscription_status)
VALUES 
  ('a0000000-0000-0000-0000-000000000001', 'SCHOOL-ALPHA', 'Alpha International Academy', 'active', 'enterprise', 'active'),
  ('b0000000-0000-0000-0000-000000000002', 'SCHOOL-BETA', 'Beta Public Grammar School', 'active', 'enterprise', 'active')
ON CONFLICT (code) DO UPDATE SET status = 'active';

-- Create test profiles for all canonical roles
-- 1. Alpha Accountant (Maker)
INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
VALUES ('00000000-0000-0000-0000-000000000001', 'SCHOOL-ALPHA', 'Ramesh Accountant', 'ramesh@alpha.edu', 'accountant', 'ACC', true, 'active')
ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'accountant', role_code = 'ACC', school_id = 'SCHOOL-ALPHA', status = 'active';

-- 2. Alpha Principal (Checker)
INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
VALUES ('00000000-0000-0000-0000-000000000002', 'SCHOOL-ALPHA', 'Dr. Sharma Principal', 'sharma@alpha.edu', 'principal', 'PRIN', true, 'active')
ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = 'SCHOOL-ALPHA', status = 'active';

-- 3. Beta Principal (Cross-Tenant Checker)
INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
VALUES ('00000000-0000-0000-0000-000000000003', 'SCHOOL-BETA', 'Dr. Verma Beta Principal', 'verma@beta.edu', 'principal', 'PRIN', true, 'active')
ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'principal', role_code = 'PRIN', school_id = 'SCHOOL-BETA', status = 'active';

-- 4. Alpha Student (Aarav)
INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
VALUES ('00000000-0000-0000-0000-000000000004', 'SCHOOL-ALPHA', 'Aarav Student', 'aarav@alpha.edu', 'student', 'STU', true, 'active')
ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = 'SCHOOL-ALPHA', status = 'active';

-- 5. Beta Student (Kabir)
INSERT INTO public.profiles (id, school_id, full_name, email, role, role_code, is_active, status)
VALUES ('00000000-0000-0000-0000-000000000005', 'SCHOOL-BETA', 'Kabir Beta Student', 'kabir@beta.edu', 'student', 'STU', true, 'active')
ON CONFLICT (id) DO UPDATE SET is_active = true, role = 'student', role_code = 'STU', school_id = 'SCHOOL-BETA', status = 'active';

-- Seed original fee ledger entry for SCHOOL-ALPHA (Using real TEXT ID matching schema)
INSERT INTO public.fee_ledger (
  id, school_id, student_id, student_name, class_name, roll_number,
  amount, payment_mode, razorpay_payment_id, status, created_at
)
VALUES (
  'TXN-ALPHA-1001',
  'SCHOOL-ALPHA',
  '00000000-0000-0000-0000-000000000004',
  'Aarav Student',
  'Class 10-A',
  '101',
  15000.00,
  'ONLINE',
  'pay_alpha_test_1001',
  'paid',
  now()
)
ON CONFLICT (id) DO NOTHING;

-- Seed original fee ledger entry for SCHOOL-BETA
INSERT INTO public.fee_ledger (
  id, school_id, student_id, student_name, class_name, roll_number,
  amount, payment_mode, razorpay_payment_id, status, created_at
)
VALUES (
  'TXN-BETA-2001',
  'SCHOOL-BETA',
  '00000000-0000-0000-0000-000000000005',
  'Kabir Beta Student',
  'Class 10-B',
  '201',
  18000.00,
  'ONLINE',
  'pay_beta_test_2001',
  'paid',
  now()
)
ON CONFLICT (id) DO NOTHING;

RAISE NOTICE 'SUCCESS: Test fixtures initialized for SCHOOL-ALPHA and SCHOOL-BETA.';


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 3: VERIFYING CROSS-TENANT DATA ISOLATION';
RAISE NOTICE '====================================================================';

-- Test 3.1: Alpha Principal cannot see Beta records under RLS
DO $$
DECLARE
  v_visible_beta_fees int;
  v_visible_beta_profiles int;
BEGIN
  -- Set Alpha Principal context
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  SELECT count(*) INTO v_visible_beta_fees
  FROM public.fee_ledger
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_fees > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta fee_ledger records! Count: %', v_visible_beta_fees;
  END IF;

  SELECT count(*) INTO v_visible_beta_profiles
  FROM public.profiles
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_profiles > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta student profiles! Count: %', v_visible_beta_profiles;
  END IF;

  RAISE NOTICE 'SUCCESS: RLS strictly enforces cross-tenant read barrier.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 4: VERIFYING MAKER-CHECKER REVERSALS & SELF-APPROVAL BLOCKS';
RAISE NOTICE '====================================================================';

-- Test 4.1: Alpha Accountant creates reversal request
DO $$
DECLARE
  v_res jsonb;
  v_req_id uuid;
BEGIN
  -- Alpha Accountant session (Maker)
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_res := public.request_fee_reversal(
    'TXN-ALPHA-1001',
    15000.00,
    'Duplicate payment charge via gateway'
  );

  IF v_res IS NULL OR (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: request_fee_reversal failed: %', v_res;
  END IF;

  v_req_id := (v_res->>'request_id')::uuid;
  RAISE NOTICE 'SUCCESS: Reversal request % created by Alpha Accountant.', v_req_id;
END $$;

-- Test 4.2: Self-Approval Prevention (Maker cannot approve own request)
DO $$
DECLARE
  v_req_id uuid;
  v_failed boolean := false;
BEGIN
  SELECT id INTO v_req_id FROM public.fee_reversal_requests 
  WHERE entry_id = 'TXN-ALPHA-1001' AND status = 'pending_approval' LIMIT 1;

  -- Alpha Accountant session attempts approval
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  BEGIN
    PERFORM public.approve_fee_reversal(v_req_id, 'Self-approval attempt');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
    RAISE NOTICE 'EXPECTED SUCCESS: Maker self-approval blocked by constraint: %', SQLERRM;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Accountant was permitted to approve their own reversal!';
  END IF;
END $$;

-- Test 4.3: Cross-Tenant Approval Prevention (Beta Principal cannot approve Alpha reversal)
DO $$
DECLARE
  v_req_id uuid;
  v_failed boolean := false;
BEGIN
  SELECT id INTO v_req_id FROM public.fee_reversal_requests 
  WHERE entry_id = 'TXN-ALPHA-1001' AND status = 'pending_approval' LIMIT 1;

  -- Beta Principal session attempts approval
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000003', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-BETA', true);

  BEGIN
    PERFORM public.approve_fee_reversal(v_req_id, 'Cross-tenant approval attempt');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
    RAISE NOTICE 'EXPECTED SUCCESS: Cross-tenant approval blocked by constraint: %', SQLERRM;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Beta Principal approved Alpha reversal across institutions!';
  END IF;
END $$;

-- Test 4.4: Legitimate Approval by Alpha Principal
DO $$
DECLARE
  v_req_id uuid;
  v_res jsonb;
  v_orig_status text;
  v_credit_count int;
BEGIN
  SELECT id INTO v_req_id FROM public.fee_reversal_requests 
  WHERE entry_id = 'TXN-ALPHA-1001' AND status = 'pending_approval' LIMIT 1;

  -- Alpha Principal session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  v_res := public.approve_fee_reversal(v_req_id, 'Approved by Principal Dr. Sharma');

  IF (v_res->>'success')::boolean != true THEN
    RAISE EXCEPTION 'FAILURE: Legitimate approval failed: %', v_res;
  END IF;

  -- Verify original entry is now reversed
  SELECT status INTO v_orig_status FROM public.fee_ledger WHERE id = 'TXN-ALPHA-1001';
  IF v_orig_status != 'reversed' THEN
    RAISE EXCEPTION 'FAILURE: Original ledger entry status is %, expected reversed', v_orig_status;
  END IF;

  -- Verify credit note exists with negative amount and original_entry_id linkage
  SELECT count(*) INTO v_credit_count FROM public.fee_ledger 
  WHERE school_id = 'SCHOOL-ALPHA' AND original_entry_id = 'TXN-ALPHA-1001' AND amount = -15000.00;

  IF v_credit_count = 0 THEN
    RAISE EXCEPTION 'FAILURE: Offsetting credit note entry was not generated in fee_ledger!';
  END IF;

  RAISE NOTICE 'SUCCESS: Legitimate Maker-Checker reversal verified with offsetting credit note.';
END $$;

-- Test 4.5: Accountant cannot directly execute reverse_fee_entry RPC
DO $$
DECLARE
  v_failed boolean := false;
  v_res jsonb;
BEGIN
  -- Alpha Accountant session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  v_res := public.reverse_fee_entry('TXN-ALPHA-1001', 'Direct reversal bypass attempt');
  
  IF (v_res->>'success')::boolean = true THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Accountant bypassed Maker-Checker via direct RPC execution!';
  ELSE
    RAISE NOTICE 'EXPECTED SUCCESS: Direct reversal by non-executive rejected with message: %', v_res->>'error';
  END IF;
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 5: VERIFYING PROFILE PRIVILEGE ESCALATION PREVENTION';
RAISE NOTICE '====================================================================';

-- Test 5.1: Student Aarav attempts to self-promote to 'PRIN' / 'principal'
DO $$
DECLARE
  v_failed boolean := false;
BEGIN
  -- Alpha Student session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000004', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  BEGIN
    UPDATE public.profiles
    SET role = 'principal',
        role_code = 'PRIN'
    WHERE id = '00000000-0000-0000-0000-000000000004';
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
    RAISE NOTICE 'EXPECTED SUCCESS: Role self-promotion blocked by database trigger: %', SQLERRM;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student was able to escalate their own role to principal!';
  END IF;
END $$;

-- Test 5.2: Student Aarav attempts to transfer school_id to 'SCHOOL-BETA'
DO $$
DECLARE
  v_failed boolean := false;
BEGIN
  -- Alpha Student session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000004', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  BEGIN
    UPDATE public.profiles
    SET school_id = 'SCHOOL-BETA'
    WHERE id = '00000000-0000-0000-0000-000000000004';
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
    RAISE NOTICE 'EXPECTED SUCCESS: School_id tenant jump blocked by database trigger: %', SQLERRM;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Student was able to jump tenants via profile modification!';
  END IF;
END $$;

-- Test 5.3: Student can update allowed non-privileged fields (e.g. phone)
DO $$
BEGIN
  -- Alpha Student session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000004', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  UPDATE public.profiles
  SET phone = '+91-9876543210'
  WHERE id = '00000000-0000-0000-0000-000000000004';

  RAISE NOTICE 'SUCCESS: Non-privileged profile fields remain cleanly editable.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 6: VERIFYING PDF QUEUE TENANT LEASE ISOLATION';
RAISE NOTICE '====================================================================';

-- Seed a PDF job for Beta School
INSERT INTO public.pdf_jobs (
  id, school_id, job_type, payload, status, created_at
)
VALUES (
  '99999999-9999-9999-9999-999999999999',
  'SCHOOL-BETA',
  'STUDENT_REPORT_CARD',
  '{"student_id": "STU-BETA-01"}'::jsonb,
  'Queued',
  now()
)
ON CONFLICT (id) DO NOTHING;

-- Alpha Principal tries to claim Beta School's PDF job -> MUST FAIL
DO $$
DECLARE
  v_failed boolean := false;
BEGIN
  -- Alpha Principal session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  BEGIN
    PERFORM * FROM public.claim_next_pdf_job('SCHOOL-BETA');
  EXCEPTION WHEN OTHERS THEN
    v_failed := true;
    RAISE NOTICE 'EXPECTED SUCCESS: Cross-tenant claim_next_pdf_job blocked: %', SQLERRM;
  END;

  IF NOT v_failed THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Cross-tenant claim_next_pdf_job did not throw an exception!';
  END IF;

  RAISE NOTICE 'SUCCESS: PDF queue tenant lease isolation verified.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 7: VERIFYING AUDIT LOG RECORDING & IMMUTABILITY';
RAISE NOTICE '====================================================================';

-- Test 7.1: Verify audit_logs table exists and accepts legitimate audit entries
DO $$
DECLARE
  v_log_id uuid := gen_random_uuid();
  v_count int;
BEGIN
  -- Alpha Principal session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  INSERT INTO public.audit_logs (
    id, school_id, user_name, user_role, action, entity_type, details, status
  )
  VALUES (
    v_log_id, 'SCHOOL-ALPHA', 'Dr. Sharma Principal', 'PRIN', 'EXAMINATION_PUBLISHED', 'EXAM', 'Published Class 10 Midterms', 'Verified'
  );

  SELECT count(*) INTO v_count
  FROM public.audit_logs
  WHERE id = v_log_id AND school_id = 'SCHOOL-ALPHA';

  IF v_count = 0 THEN
    RAISE EXCEPTION 'FAILURE: Audit log row was not recorded in public.audit_logs!';
  END IF;

  RAISE NOTICE 'SUCCESS: Audit log entry successfully persisted.';
END $$;

-- Test 7.2: Verify cross-tenant audit log isolation (Beta Principal cannot view Alpha audit logs)
DO $$
DECLARE
  v_visible_alpha_logs int;
BEGIN
  -- Beta Principal session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000003', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-BETA', true);

  SELECT count(*) INTO v_visible_alpha_logs
  FROM public.audit_logs
  WHERE school_id = 'SCHOOL-ALPHA';

  IF v_visible_alpha_logs > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Beta Principal can read Alpha audit logs! Count: %', v_visible_alpha_logs;
  END IF;

  RAISE NOTICE 'SUCCESS: Audit logs strictly isolated by tenant boundary.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 8: VERIFYING PAYMENT ORDER TENANT ISOLATION';
RAISE NOTICE '====================================================================';

-- Seed payment orders for Alpha and Beta
INSERT INTO public.payment_orders (
  order_id, school_id, student_id, student_name, amount, status
)
VALUES
  ('order_alpha_test_1001', 'SCHOOL-ALPHA', '00000000-0000-0000-0000-000000000004', 'Aarav Student', 15000.00, 'paid'),
  ('order_beta_test_2001', 'SCHOOL-BETA', '00000000-0000-0000-0000-000000000005', 'Kabir Beta Student', 18000.00, 'paid')
ON CONFLICT (order_id) DO NOTHING;

-- Test 8.1: Alpha Principal cannot see Beta payment orders under RLS
DO $$
DECLARE
  v_visible_beta_orders int;
BEGIN
  -- Alpha Principal session
  PERFORM set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', true);
  PERFORM set_config('request.jwt.claim.school_id', 'SCHOOL-ALPHA', true);

  SELECT count(*) INTO v_visible_beta_orders
  FROM public.payment_orders
  WHERE school_id = 'SCHOOL-BETA';

  IF v_visible_beta_orders > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Alpha Principal can read Beta payment orders! Count: %', v_visible_beta_orders;
  END IF;

  RAISE NOTICE 'SUCCESS: Payment orders strictly isolated by institutional tenant.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'STAGE 9: VERIFYING PERMISSIVE RLS POLICY DECONFLICTION';
RAISE NOTICE '====================================================================';

-- Ensure legacy leaky permissive policies are eliminated
DO $$
DECLARE
  v_count int;
BEGIN
  SELECT count(*) INTO v_count
  FROM pg_policies
  WHERE tablename = 'test_scores' AND policyname = 'test_scores_select';

  IF v_count > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Legacy permissive test_scores_select policy still exists! OR-leakage active.';
  END IF;

  SELECT count(*) INTO v_count
  FROM pg_policies
  WHERE tablename = 'class_tests' AND policyname = 'class_tests_select';

  IF v_count > 0 THEN
    RAISE EXCEPTION 'CRITICAL SECURITY FAILURE: Legacy permissive class_tests_select policy still exists! OR-leakage active.';
  END IF;

  RAISE NOTICE 'SUCCESS: All legacy leaky permissive policies confirmed eliminated.';
END $$;


RAISE NOTICE '====================================================================';
RAISE NOTICE 'ALL 9 STAGING VERIFICATION STAGES PASSED WITH ZERO VIOLATIONS!';
RAISE NOTICE '====================================================================';

-- Explicit transaction rollback guarantees staging database remains pristine
ROLLBACK;
