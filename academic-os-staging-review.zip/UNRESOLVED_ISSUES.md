# ACADEMIC OS — UNRESOLVED ISSUES & OPERATIONAL PREREQUISITES
**Document Classification:** Technical Disclosure & Staging Prerequisites  
**Target Reviewer:** Independent Security & Database Migration Reviewer  

---

## 1. Supabase Auth (`auth.users`) vs. Application Profiles (`public.profiles`)
* **Finding:**  
  In the Supabase architecture, user authentication credentials (`auth.users`) exist in an internal schema managed by Supabase GoTrue, while application profiles exist in `public.profiles`.
* **Current Behavior:**  
  When an institution is provisioned via `/master-setup` or the `provision_institutional_school` RPC, a row is created in `public.schools`, `public.school_licenses`, and `public.profiles` (with `role = 'principal'` or `'trustee'`, and `role_code = 'PRIN-01'` or `'HOD-01'`).
* **Requirement for Live Sign-in:**  
  Inserting a row into `public.profiles` does NOT automatically register a hashed password in `auth.users`. To enable password-based login through Supabase Auth, the platform administrator must either:
  1. Invite the user via Supabase Dashboard -> **Authentication** -> **Users** -> **Invite User**; or
  2. Trigger the Supabase Auth Admin API (`supabase.auth.admin.createUser`) using the `SUPABASE_SERVICE_ROLE_KEY` in a secure serverless script; or
  3. Have the user sign up with the provisioned email and bind their profile UUID to `auth.users.id`.
* **Resolution in Staging Package:**  
  The RPC return value and `OWNER_ACTIONS.md` explicitly document this separation (`auth_account_created: false`) so operators do not assume `public.profiles` insertion creates a GoTrue password credential.

---

## 2. Mandatory Sequential Execution of Migrations
* **Finding:**  
  Migration 22 depends on schema objects and columns created in migration 21 (e.g. `public.audit_logs`, `idempotency_key` on `fee_ledger`), and migration 23 depends on `public.profiles` modifications in migration 22.
* **Requirement:**  
  The migrations must be executed sequentially in the Supabase SQL Editor:
  1. `migrations/21_security_and_financial_hardening.sql`
  2. `migrations/22_phase2_security_and_rls_hardening.sql`
  3. `migrations/23_sales_readiness_and_subscription_hardening.sql`
* **Safe Guards Added:**  
  Both migrations 22 and 23 have been fortified with idempotent column checks (`ADD COLUMN IF NOT EXISTS`) and index checks (`IF NOT EXISTS`) so that even if executed out of order or re-executed, PostgreSQL will not crash.

---

## 3. Remote Live Database Verification Pending Owner Execution
* **Finding:**  
  By design and strict mandate, the AI assistant does not possess credentials to execute DDL or DML against the owner's remote live Supabase database.
* **Status:**  
  The verification script `verification/staging-database-verification.sql` has been reconstructed with 9 isolated test stages and is wrapped in an explicit `BEGIN ... ROLLBACK;` block.
* **Requirement:**  
  The repository owner must copy and execute `verification/staging-database-verification.sql` in their Supabase SQL Editor and confirm that all 9 stages output their respective `NOTICE` lines.

---

## 4. Live Gateway Key Provisioning
* **Finding:**  
  Serverless online fee collection endpoints (`/api/razorpay/create-order` and `/api/razorpay/verify-payment`) operate in test mode when provided valid Razorpay test keys.
* **Requirement:**  
  The owner must register a Razorpay account, obtain `rzp_test_...` credentials, and configure `VITE_RAZORPAY_KEY_ID`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET` in Vercel before live payment modal verification can occur.

---

## 5. Summary Risk Assessment
* **Schema Integrity:** HIGH CONFIDENCE — All column names, foreign keys, and function signatures have been verified against real migration files (01–20).
* **Cross-Tenant Isolation:** HIGH CONFIDENCE — Single-authority RLS policies on `schools`, `profiles`, `fee_ledger`, `fee_reversal_requests`, and `payment_orders` strictly prevent data leakage.
* **Privilege Escalation:** HIGH CONFIDENCE — Database-level trigger prevents client manipulation of `role`, `role_code`, `school_id`, and `status`.
* **Production Deployment Readiness:** CONDITIONAL — Requires owner execution of migrations and staging verification script in their staging Supabase project.

