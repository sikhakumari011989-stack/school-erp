-- ==============================================================================
-- ROLLBACK SCRIPT: rollback_21_22_23.sql
-- Academic OS: Safe, Non-Destructive Rollback for Migrations 23, 22, and 21
-- Purpose: Safely revert function signatures and policies in staging/production
--          WITHOUT destroying payment history, reversal logs, or tenant data,
--          and WITHOUT restoring known-insecure permissive policies.
-- ==============================================================================

BEGIN;

RAISE NOTICE '====================================================================';
RAISE NOTICE 'STARTING SAFE NON-DESTRUCTIVE ROLLBACK (MIGRATIONS 23, 22, 21)';
RAISE NOTICE '====================================================================';

-- ------------------------------------------------------------------------------
-- 1. ROLLBACK MIGRATION 23 (Sales Readiness & Subscription Hardening)
-- ------------------------------------------------------------------------------
RAISE NOTICE 'Reverting Migration 23 extensions...';

-- Drop subscription renewal function added in 23
DROP FUNCTION IF EXISTS public.renew_school_subscription(text, text, int, text, numeric);

-- Revert provision_institutional_school back to phase 2 definition
CREATE OR REPLACE FUNCTION public.provision_institutional_school(
  p_name text,
  p_code text,
  p_admin_name text,
  p_admin_role_code text,
  p_admin_email text DEFAULT '',
  p_admin_phone text DEFAULT '',
  p_address text DEFAULT '',
  p_mode text DEFAULT 'school',
  p_tier text DEFAULT 'enterprise',
  p_validity_days int DEFAULT 365
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_school_id uuid;
  v_clean_code text := UPPER(TRIM(p_code));
  v_expires_at timestamptz := now() + (p_validity_days || ' days')::interval;
  v_license_key text := 'LIC-' || v_clean_code || '-' || floor(extract(epoch from now()))::text;
  v_result jsonb;
BEGIN
  IF COALESCE(auth.role(), '') != 'service_role' AND NULLIF(current_setting('app.is_master_operator', true), '') IS NULL THEN
    RAISE EXCEPTION 'Unauthorized: Platform Owner service-role authority required for institutional provisioning.';
  END IF;

  IF v_clean_code IS NULL OR length(v_clean_code) < 2 THEN
    RAISE EXCEPTION 'School code must be at least 2 characters.';
  END IF;

  INSERT INTO public.schools (
    code, name, phone, address, status, subscription_status, subscription_tier, subscription_expires_at, institution_mode, created_at
  )
  VALUES (
    v_clean_code, TRIM(p_name), TRIM(p_admin_phone), TRIM(p_address), 'active', 'active', p_tier, v_expires_at, p_mode, now()
  )
  ON CONFLICT (code) DO UPDATE
  SET
    name = EXCLUDED.name,
    phone = COALESCE(NULLIF(EXCLUDED.phone, ''), public.schools.phone),
    address = COALESCE(NULLIF(EXCLUDED.address, ''), public.schools.address),
    status = 'active',
    subscription_status = 'active',
    subscription_tier = EXCLUDED.subscription_tier,
    subscription_expires_at = EXCLUDED.subscription_expires_at,
    institution_mode = EXCLUDED.institution_mode
  RETURNING id INTO v_school_id;

  INSERT INTO public.school_licenses (
    school_id, school_code, license_key, tier, status, starts_at, expires_at, updated_at
  )
  VALUES (
    v_school_id, v_clean_code, v_license_key, p_tier, 'active', now(), v_expires_at, now()
  )
  ON CONFLICT (license_key) DO UPDATE
  SET status = 'active', expires_at = v_expires_at, updated_at = now();

  v_result := jsonb_build_object(
    'success', true,
    'school_id', v_school_id,
    'school_code', v_clean_code,
    'school_name', TRIM(p_name),
    'status', 'active',
    'subscription_status', 'active',
    'expires_at', v_expires_at,
    'license_key', v_license_key
  );

  RETURN v_result;
END;
$$;

-- NOTE: public.payment_orders is PRESERVED to protect transaction records and payment history.
-- We do NOT execute DROP TABLE on payment_orders.


-- ------------------------------------------------------------------------------
-- 2. ROLLBACK MIGRATION 22 (Phase 2 Security & RLS Hardening)
-- ------------------------------------------------------------------------------
RAISE NOTICE 'Reverting Migration 22 Phase 2 RPCs...';

-- Drop Phase 2 Maker-Checker RPCs
DROP FUNCTION IF EXISTS public.request_fee_reversal(text, numeric, text);
DROP FUNCTION IF EXISTS public.request_fee_reversal(uuid, numeric, text);
DROP FUNCTION IF EXISTS public.approve_fee_reversal(uuid, text);
DROP FUNCTION IF EXISTS public.reject_fee_reversal(uuid, text);

-- Drop profile privileged columns protection trigger if resetting
DROP TRIGGER IF EXISTS trg_protect_profile_privileged_columns ON public.profiles;
DROP FUNCTION IF EXISTS public.protect_profile_privileged_columns();

-- Revert claim_next_pdf_job back to basic version
CREATE OR REPLACE FUNCTION public.claim_next_pdf_job(p_school_id text)
RETURNS SETOF public.pdf_jobs
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  UPDATE public.pdf_jobs
  SET status = 'Processing',
      attempts = attempts + 1,
      locked_until = now() + interval '2 minutes'
  WHERE id = (
    SELECT id
    FROM public.pdf_jobs
    WHERE school_id = p_school_id
      AND status = 'Queued'
      AND (locked_until IS NULL OR locked_until < now())
      AND attempts < 3
    ORDER BY created_at ASC
    FOR UPDATE SKIP LOCKED
    LIMIT 1
  )
  RETURNING *;
END;
$$;

-- Secure schools policy: preserve active status filter (DO NOT restore known-insecure USING (true))
DROP POLICY IF EXISTS "schools_canonical_select" ON public.schools;
CREATE POLICY "schools_canonical_select"
  ON public.schools FOR SELECT TO authenticated, anon
  USING (status = 'active');


-- ------------------------------------------------------------------------------
-- 3. ROLLBACK MIGRATION 21 (Security & Financial Hardening)
-- ------------------------------------------------------------------------------
RAISE NOTICE 'Reverting Migration 21 financial functions...';

-- NOTE: public.fee_reversal_requests and public.audit_logs are PRESERVED
-- to prevent silent destruction of historical reversal records and compliance audit trails.
-- We do NOT execute DROP TABLE on fee_reversal_requests or audit_logs.

-- Drop reverse_fee_entry functions
DROP FUNCTION IF EXISTS public.reverse_fee_entry(text, text, text, text);
DROP FUNCTION IF EXISTS public.reverse_fee_entry(uuid, text, text, text);

-- Note: Indexes idx_fee_ledger_idempotency and idx_fee_ledger_original_entry are preserved
-- as they are performance optimizations that do not affect correctness.

RAISE NOTICE '====================================================================';
RAISE NOTICE 'SAFE ROLLBACK COMPLETED SUCCESSFULLY. DATABASE RESTORED SAFELY.';
RAISE NOTICE '====================================================================';

COMMIT;
