# ACADEMIC OS — STAGING HANDOVER & OPERATIONAL RUNBOOK
**Target Environment:** Supabase PostgreSQL + Vercel Serverless + Razorpay Test Gateway  
**Document Classification:** Confidential — Platform Owner Operational Manual  
**Security Guarantee:** Contains NO hardcoded secrets or sensitive credentials.

---

## 1. PRE-DEPLOYMENT SCHEMA INSPECTION & AUDIT REPORT

Before executing migrations on your live staging instance, verify the following findings from the independent architectural inspection:

### A. Resolved Migration Conflicts & Schema Deconflictions
1. **Migration 21 Fee Reversal Authorization & Tenant Isolation Enforced:**  
   In migration 21, `reverse_fee_entry` previously accepted a caller-supplied `p_authorized_by` without checking `auth.uid()`, executive role authority, or tenant matching. It has been strictly refactored so that:
   - Caller must have a valid authenticated session (`auth.uid() IS NOT NULL`).
   - Caller must be an executive admin (`public.is_admin_or_executive()`).
   - Cross-tenant fee reversals are blocked (`v_fee_record.school_id = v_tenant`).
   - Approver name is derived strictly from `auth.uid()` / `public.profiles`.
2. **Immutable `audit_logs` Table & Real Trigger Insertion Restored:**  
   `public.log_audit_event()` previously returned `NEW` or `OLD` without logging. Migration 21 now creates the dedicated `public.audit_logs` table with strict RLS and updates `log_audit_event()` to insert structured audit records (`school_id`, `user_id`, `action`, `entity_type`, `old_data`, `new_data`, `status`, `created_at`).
3. **Database-Level Protection of Privileged Profile Columns:**  
   In migration 22, an immutable `BEFORE UPDATE` trigger (`protect_profile_privileged_columns`) blocks non-administrative users from modifying their own `role`, `role_code`, `school_id`, `status`, or `is_active`. Even executive administrators are prevented from modifying `school_id` to transfer profiles across institutions.
4. **Migration 23 Administrator Profile Insertion Corrected:**  
   `provision_institutional_school` now explicitly supplies an explicit `id uuid`, uses `text` for `school_id` matching `public.profiles`, updates `(school_id, role_code)` safely via `idx_profiles_school_role_code`, and clearly returns `auth_account_created: false` to clarify that an application profile is distinct from a Supabase Auth (`auth.users`) credential.
5. **Reconciliation of `fee_ledger.id` TEXT versus UUID Discrepancy:**  
   `public.fee_ledger.id` is typed as `text PRIMARY KEY` (`TXN-...`). All references in `fee_reversal_requests.entry_id`, `request_fee_reversal`, `approve_fee_reversal`, and `reverse_fee_entry` use `text` with ZERO unsafe casts to UUID. Credit note entries generate text identifiers (`CN-...`).
6. **Non-Destructive, Safe Rollback Procedure:**  
   `supabase/migrations/rollback_21_22_23.sql` has been redesigned to be strictly non-destructive. It does NOT drop `payment_orders`, `fee_reversal_requests`, or `audit_logs`, preventing silent data loss, and does NOT restore known-insecure permissive policies.
7. **Elimination of Permissive OR-Leakage Policies:**  
   Migration 22 explicitly drops legacy policies on `public.schools`, `public.profiles`, `public.class_tests`, and `public.test_scores`, preventing permissive policy combinations.

### B. Complete `SECURITY DEFINER` Permissions Matrix
Every elevated function enforces `search_path = public` to prevent search path poisoning, and has had unsafe permissions revoked:

| Function Signature | search_path | anon | authenticated | service_role | Enforced Caller Checks |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `provision_institutional_school(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `renew_school_subscription(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `set_school_license_status(...)` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `get_master_schools_roster()` | `public` | ❌ REVOKED | ❌ REVOKED | ✅ GRANTED | `auth.role() = 'service_role'` |
| `claim_next_pdf_job(text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | Authenticated tenant match enforced |
| `request_fee_reversal(text, numeric, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_financial_manager()` + tenant isolation |
| `approve_fee_reversal(uuid, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + Maker != Checker |
| `reject_fee_reversal(uuid, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + tenant match |
| `reverse_fee_entry(text, text, text, text)` | `public` | ❌ REVOKED | ✅ GRANTED | ✅ GRANTED | `is_admin_or_executive()` + `auth.uid()` approver |

### C. Data Preservation Guarantee
- **Zero Destructive Statements:** Migrations 21, 22, and 23 contain NO `DROP TABLE`, `TRUNCATE`, or destructive `DELETE` statements on student, teacher, school, or financial data.
- **Idempotency:** All statements use `IF NOT EXISTS`, `OR REPLACE`, and `ON CONFLICT DO UPDATE`. Running them against existing databases will not damage existing tenant records.

---

## 2. SAFE SEQUENTIAL STAGING EXECUTION RUNBOOK

Execute the following migrations in your Supabase project in the exact order specified below:

### Step 2.1: Open Supabase SQL Editor
1. Log in to [Supabase Dashboard](https://supabase.com/dashboard).
2. Select your staging project.
3. In the left navigation, click **SQL Editor**, then click **New Query**.

### Step 2.2: Execute Migration 21 (Financial & Base Security Hardening)
1. Open [`supabase/migrations/21_security_and_financial_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/21_security_and_financial_hardening.sql) in your code editor.
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run** (or press `Ctrl+Enter`).
4. Verify the output message: `Success. No rows returned`.

### Step 2.3: Execute Migration 22 (Maker-Checker & RLS Hardening)
1. Open [`supabase/migrations/22_phase2_security_and_rls_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/22_phase2_security_and_rls_hardening.sql) in your code editor.
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run**.
4. Verify the output message: `Success. No rows returned`.

### Step 2.4: Execute Migration 23 (Sales Readiness & Subscriptions)
1. Open [`supabase/migrations/23_sales_readiness_and_subscription_hardening.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/23_sales_readiness_and_subscription_hardening.sql) in your code editor.
2. Copy the entire file contents into the Supabase SQL Editor.
3. Click **Run**.
4. Verify the output message: `Success. No rows returned`.

---

## 3. EXECUTABLE DATABASE VALIDATION

Run the automated PostgreSQL verification script to validate tenant barriers, permissions revocations, privilege escalation protection, audit logging, and maker-checker locks:

1. In **Supabase SQL Editor**, open a **New Query**.
2. Open [`tests/staging-database-verification.sql`](file:///c:/Users/Astik/school-app/tests/staging-database-verification.sql).
3. Copy all lines into the query editor and click **Run**.
4. Confirm that the execution log completes with:
   ```text
   NOTICE: STAGE 1: VERIFYING MASTER PROVISIONING PERMISSIONS REVOCATION
   NOTICE: SUCCESS: All Master Provisioning RPCs are strictly isolated to service_role.
   NOTICE: STAGE 2: SETUP ISOLATED TEST FIXTURES (ALPHA & BETA SCHOOLS)
   NOTICE: SUCCESS: Test fixtures initialized for SCHOOL-ALPHA and SCHOOL-BETA.
   NOTICE: STAGE 3: VERIFYING CROSS-TENANT DATA ISOLATION
   NOTICE: SUCCESS: RLS strictly enforces cross-tenant read barrier.
   NOTICE: STAGE 4: VERIFYING MAKER-CHECKER REVERSALS & SELF-APPROVAL BLOCKS
   NOTICE: SUCCESS: Reversal request created by Alpha Accountant.
   NOTICE: EXPECTED SUCCESS: Maker self-approval blocked by constraint.
   NOTICE: EXPECTED SUCCESS: Cross-tenant approval blocked by constraint.
   NOTICE: SUCCESS: Legitimate Maker-Checker reversal verified with offsetting credit note.
   NOTICE: EXPECTED SUCCESS: Direct reversal by non-executive rejected.
   NOTICE: STAGE 5: VERIFYING PROFILE PRIVILEGE ESCALATION PREVENTION
   NOTICE: EXPECTED SUCCESS: Role self-promotion blocked by database trigger.
   NOTICE: EXPECTED SUCCESS: School_id tenant jump blocked by database trigger.
   NOTICE: SUCCESS: Non-privileged profile fields remain cleanly editable.
   NOTICE: STAGE 6: VERIFYING PDF QUEUE TENANT LEASE ISOLATION
   NOTICE: EXPECTED SUCCESS: Cross-tenant claim_next_pdf_job blocked.
   NOTICE: SUCCESS: PDF queue tenant lease isolation verified.
   NOTICE: STAGE 7: VERIFYING AUDIT LOG RECORDING & IMMUTABILITY
   NOTICE: SUCCESS: Audit log entry successfully persisted.
   NOTICE: SUCCESS: Audit logs strictly isolated by tenant boundary.
   NOTICE: STAGE 8: VERIFYING PAYMENT ORDER TENANT ISOLATION
   NOTICE: SUCCESS: Payment orders strictly isolated by institutional tenant.
   NOTICE: STAGE 9: VERIFYING PERMISSIVE RLS POLICY DECONFLICTION
   NOTICE: SUCCESS: All legacy leaky permissive policies confirmed eliminated.
   NOTICE: ALL 9 STAGING VERIFICATION STAGES PASSED WITH ZERO VIOLATIONS!
   ```
   *(Note: The verification script runs inside an explicit `BEGIN ... ROLLBACK;` block, leaving your staging database completely clean).*

---

## 4. VERCEL ENVIRONMENT VARIABLES CONFIGURATION

In your [Vercel Project Settings](https://vercel.com) under **Environment Variables**, configure the following keys:

| Variable Name | Environment Scope | Secret? | Source / Description |
| :--- | :--- | :--- | :--- |
| `VITE_SUPABASE_URL` | Production, Preview | No | Supabase Dashboard -> Project Settings -> API -> Project URL |
| `VITE_SUPABASE_ANON_KEY` | Production, Preview | No | Supabase Dashboard -> Project Settings -> API -> `anon` public key |
| `SUPABASE_SERVICE_ROLE_KEY` | Production, Preview | **YES** | Supabase Dashboard -> Project Settings -> API -> `service_role` secret key |
| `VITE_RAZORPAY_KEY_ID` | Production, Preview | No | Razorpay Dashboard -> Settings -> API Keys (`rzp_test_...` or `rzp_live_...`) |
| `RAZORPAY_KEY_ID` | Production, Preview | No | Same value as `VITE_RAZORPAY_KEY_ID` (used by serverless API) |
| `RAZORPAY_KEY_SECRET` | Production, Preview | **YES** | Razorpay Dashboard -> Settings -> API Keys -> Key Secret |
| `RAZORPAY_WEBHOOK_SECRET` | Production, Preview | **YES** | Webhook secret configured in Razorpay Webhooks dashboard |
| `MASTER_SETUP_KEY` | Production, Preview | **YES** | Custom passkey (min 20 characters) for unlocking `/master-setup` |
| `MASTER_TOKEN_SECRET` | Production, Preview | **YES** | 64-char hex string (generate via `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`) |
| `BIOMETRIC_DEVICE_SECRET`| Production, Preview | **YES** | Shared secret for biometric turnstile hardware |
| `VITE_SENTRY_DSN` | Production, Preview | No | Sentry.io Client Key (DSN) for error reporting |

After updating environment variables, click **Deployments** -> **Redeploy** on the latest commit.

---

## 5. RAZORPAY TEST-MODE & WEBHOOK SETUP

### Step 5.1: Generate Test API Keys
1. Log in to [Razorpay Dashboard](https://dashboard.razorpay.com).
2. Toggle the dashboard to **Test Mode** (top-right header).
3. Navigate to **Account & Settings** -> **API Keys**.
4. Click **Generate Key**.
5. Copy **Key ID** to `VITE_RAZORPAY_KEY_ID` and `RAZORPAY_KEY_ID` in Vercel.
6. Copy **Key Secret** to `RAZORPAY_KEY_SECRET` in Vercel.

### Step 5.2: Create Webhook Endpoint
1. Navigate to **Account & Settings** -> **Webhooks**.
2. Click **Add New Webhook**:
   - **Webhook URL:** `https://<your-vercel-domain>/api/razorpay-webhook`
   - **Secret:** Generate a random string (e.g., `whsec_academic_os_test_2026`) and paste into `RAZORPAY_WEBHOOK_SECRET` in Vercel.
   - **Active Events:**
     - `payment.captured`
     - `payment.failed`
     - `order.paid`
     - `refund.processed`
3. Click **Save**.

---

## 6. SUPABASE STORAGE BUCKETS CONFIGURATION

Ensure private storage buckets exist for generated documents and receipts:

1. In Supabase Dashboard, open **Storage**.
2. Verify or create:
   - `institutional-documents` (Private, Public: OFF)
   - `receipt-proofs` (Private, Public: OFF)
3. Ensure RLS on storage buckets is active.

---

## 7. STAGING TEST CHECKLIST

Perform these sequential verification tests across two distinct institutions to certify production readiness:

```
[ ] TEST 1: INSTITUTIONAL ONBOARDING (SCHOOL A & SCHOOL B)
    [ ] 1.1 Navigate to /master-setup. Enter incorrect passkey -> Must receive 401 Unauthorized.
    [ ] 1.2 Enter valid MASTER_SETUP_KEY. Verify Master Setup portal opens.
    [ ] 1.3 Register School A:
        - Name: "Greenwood International School"
        - Code: "GW-01"
        - Admin: "Dr. Alok Verma" (HOD-01)
        - Tier: Enterprise (365 days)
        - Click Provision. Confirm success toast and verify school persists after page refresh.
    [ ] 1.4 Register School B:
        - Name: "St. Mary High School"
        - Code: "STM-02"
        - Admin: "Sister Teresa" (PRIN-01)
        - Click Provision. Confirm success toast.

[ ] TEST 2: EXECUTIVE ADMINISTRATOR LOGIN
    [ ] 2.1 Log in with School: "GW-01", ID: "HOD-01", Password: (provisioned password).
    [ ] 2.2 Verify Trustee Dashboard loads. Confirm institutional metrics start at zero (no fake ₹12.5L).
    [ ] 2.3 Verify school branding shows "Greenwood International School".

[ ] TEST 3: SIX CANONICAL ROLES VERIFICATION
    [ ] 3.1 PRIN (Principal): Has access to Academic Oversight, Staff, Attendance, Approvals.
    [ ] 3.2 HOD (Trustee/Admin): Has access to Financial Reports, Operational Approvals, Licensing.
    [ ] 3.3 ACC (Accountant): Has access to Fee Collection, Invoices, Reversals Request, Payroll.
    [ ] 3.4 TCH (Teacher): Has access to Class Tests, Marks Entry, Attendance. Cannot access Fees.
    [ ] 3.5 STU (Student): Has access to My Marks, Fee Invoices, Razorpay Online Payment.
    [ ] 3.6 NTS (Non-Teaching Staff): Clinical and health records strictly redacted; no academic marks.

[ ] TEST 4: FEES & RAZORPAY ONLINE CHECKOUT
    [ ] 4.1 In ACC portal, record a fee entry for Student "Aarav" (Class 10-A, ₹15,000).
    [ ] 4.2 Log in as Student Aarav. Navigate to Student Fees.
    [ ] 4.3 Click "Pay Online via Razorpay".
    [ ] 4.4 Verify Razorpay Modal opens in Test Mode. Complete test transaction using test card or NetBanking.
    [ ] 4.5 Verify order is recorded in `payment_orders` with status `paid`.
    [ ] 4.6 Verify invoice status immediately updates to "Paid" in Student Vault.

[ ] TEST 5: FINANCIAL MAKER-CHECKER REVERSAL WORKFLOW
    [ ] 5.1 Log in as Accountant (ACC). Locate fee entry for ₹15,000.
    [ ] 5.2 Click "Request Reversal". Enter reason "Double payment charged". Submit.
    [ ] 5.3 Verify status updates to "Pending Approval".
    [ ] 5.4 Attempt to approve as Accountant -> UI and database must reject (Maker cannot approve).
    [ ] 5.5 Log in as Principal (PRIN) or Trustee (HOD) of GW-01.
    [ ] 5.6 Navigate to Approvals Inbox. Locate pending reversal.
    [ ] 5.7 Click "Approve Reversal". Confirm Credit Note generated in `fee_ledger` (-₹15,000).
    [ ] 5.8 Confirm original entry status marked "reversed".

[ ] TEST 6: COMPLETE TENANT ISOLATION (ZERO CROSS-TENANT LEAKAGE)
    [ ] 6.1 Log in as School B Principal (STM-02).
    [ ] 6.2 Verify Accountant Dashboard and Fees tables show ZERO records from GW-01.
    [ ] 6.3 Attempt to fetch student marks or fee records from GW-01 -> Database returns 0 rows.
    [ ] 6.4 Approvals Inbox shows ZERO pending items from GW-01.

[ ] TEST 7: TEACHER CLASS TEST MARKS ENTRY & STUDENT PORTAL
    [ ] 7.1 Teacher creates Class Test: "Mathematics Mid-Term" (Max Marks: 50).
    [ ] 7.2 Teacher enters marks: Aarav (48/50), Rohan (42/50). Sets status to "Draft".
    [ ] 7.3 Student Aarav logs in -> Test must NOT appear (Draft status hidden).
    [ ] 7.4 Teacher clicks "Publish Marks".
    [ ] 7.5 Student Aarav logs in -> Sees score (48/50) and Class Highest (48). Cannot see Rohan's score.

[ ] TEST 8: ASYNCHRONOUS PDF BATCH JOBS
    [ ] 8.1 Trigger report card batch generation in Principal portal.
    [ ] 8.2 Verify job is queued in `pdf_jobs`.
    [ ] 8.3 Verify School B worker cannot claim School A's PDF jobs.
```

---

## 8. ROLLBACK INSTRUCTIONS

If any unexpected regression occurs during staging execution, use the automated rollback script:

1. Open **Supabase SQL Editor** -> **New Query**.
2. Open [`supabase/migrations/rollback_21_22_23.sql`](file:///c:/Users/Astik/school-app/supabase/migrations/rollback_21_22_23.sql).
3. Paste the contents into the query editor and click **Run**.
4. Confirm that the script completes with:
   `NOTICE: SAFE ROLLBACK COMPLETED SUCCESSFULLY. DATABASE RESTORED SAFELY.`
5. The rollback script:
   - Drops `renew_school_subscription` and reverts `provision_institutional_school`.
   - Drops the maker-checker reversal functions and restores baseline function signatures.
   - Drops the profile privilege escalation trigger.
   - **PRESERVES** `public.payment_orders`, `public.fee_reversal_requests`, and `public.audit_logs` without dropping tables, guaranteeing zero destruction of staging payment and reversal logs.
   - Retains secure active school filtering without restoring legacy unconstrained public read policies.
